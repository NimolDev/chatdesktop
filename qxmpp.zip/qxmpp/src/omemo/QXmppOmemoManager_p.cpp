// SPDX-FileCopyrightText: 2022 Melvin Keskin <melvo@olomono.de>
// SPDX-FileCopyrightText: 2022 Linus Jahn <lnj@kaidan.im>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#include "QXmppOmemoManager_p.h"

#include "QXmppFallback.h"
#include "QXmppOmemoDeviceElement_p.h"
#include "QXmppOmemoElement_p.h"
#include "QXmppOmemoEnvelope_p.h"
#include "QXmppOmemoIq_p.h"
#include "QXmppOmemoItems_p.h"
#include "QXmppPubSubBaseItem.h"
#include "QXmppSceEnvelope_p.h"
#include "QXmppTrustManager.h"
#include "QXmppTrustMessageElement.h"
#include "QXmppUtils.h"
#include "QXmppUtils_p.h"

#include "Async.h"
#include "OmemoCryptoProvider.h"
#include "StringLiterals.h"

#include <protocol.h>

#include <QRandomGenerator>

#undef max
#undef interface

using namespace QXmpp;
using namespace QXmpp::Private;
using namespace QXmpp::Omemo::Private;

using Error = QXmppStanza::Error;
using Manager = QXmppOmemoManager;
using ManagerPrivate = QXmppOmemoManagerPrivate;

//
// Contains address data for an OMEMO device and a method to get the corresponding OMEMO library
// data structure.
//
class Address
{
public:
    // Creates an OMEMO device address.
    //
    // \a jid is bare JID of the device owner. \a deviceId is ID of the device.
    Address(const QString &jid, uint32_t deviceId)
        : m_jid(jid.toUtf8()), m_deviceId(int32_t(deviceId))
    {
    }
    // Returns the representation of the OMEMO device address used by the OMEMO library.
    //
    // Returns the OMEMO library device address.
    signal_protocol_address data() const
    {
        return { m_jid.data(), size_t(m_jid.size()), m_deviceId };
    }

private:
    QByteArray m_jid;
    int32_t m_deviceId;
};

// Creates a PEP node configuration for the device list.
//
// Returns the device list node configuration.
static QXmppPubSubNodeConfig deviceListNodeConfig()
{
    QXmppPubSubNodeConfig config;
    config.setAccessModel(QXmppPubSubNodeConfig::Open);

    return config;
}

// Creates publish options for publishing the device list to a corresponding PEP node.
//
// Returns the device list node publish options.
static QXmppPubSubPublishOptions deviceListNodePublishOptions()
{
    QXmppPubSubPublishOptions publishOptions;
    publishOptions.setAccessModel(QXmppPubSubPublishOptions::Open);

    return publishOptions;
}

// Creates a PEP node configuration for device bundles.
//
// Returns the device bundles node configuration.
static QXmppPubSubNodeConfig deviceBundlesNodeConfig(QXmppPubSubNodeConfig::ItemLimit itemLimit = QXmppPubSubNodeConfig::Max())
{
    QXmppPubSubNodeConfig config;
    config.setAccessModel(QXmppPubSubNodeConfig::Open);
    config.setMaxItems(itemLimit);

    return config;
}

// Creates publish options for publishing device bundles to a corresponding PEP node.
//
// Returns the device bundles node publish options.
static QXmppPubSubPublishOptions deviceBundlesNodePublishOptions(QXmppPubSubNodeConfig::ItemLimit itemLimit = QXmppPubSubNodeConfig::Max())
{
    QXmppPubSubPublishOptions publishOptions;
    publishOptions.setAccessModel(QXmppPubSubPublishOptions::Open);
    publishOptions.setMaxItems(itemLimit);

    return publishOptions;
}

// Deserializes the signature of a signed public pre key.
//
// \a signedPublicPreKeySignature is signed public pre key signature location. \a
// serializedSignedPublicPreKeySignature is serialized signature of the signed public pre key.
//
// Returns whether it succeeded.
static int deserializeSignedPublicPreKeySignature(const uint8_t **signedPublicPreKeySignature, const QByteArray &serializedSignedPublicPreKeySignature)
{
    *signedPublicPreKeySignature = reinterpret_cast<const uint8_t *>(serializedSignedPublicPreKeySignature.constData());
    return serializedSignedPublicPreKeySignature.size();
}

// Extracts the JID from an address used by the OMEMO library.
//
// \a address is address containing the JID data.
//
// Returns the extracted JID.
static QString extractJid(signal_protocol_address address)
{
    return QString::fromUtf8(address.name, address.name_len);
}

static QString errorToString(const QXmppStanza::Error &err)
{
    return u"Error('" + err.text() + u"', type=" + QString::number(err.type()) + u", condition=" + QString::number(err.condition()) + u")";
}

static QString errorToString(const QXmppError &err)
{
    if (auto sErr = err.value<QXmppStanza::Error>()) {
        return errorToString(*sErr);
    }
    return err.description;
}

static void replaceChildElements(QDomElement &oldElement, const QDomElement &newElement)
{
    // remove old child elements
    while (true) {
        if (auto childElement = oldElement.firstChildElement(); !childElement.isNull()) {
            oldElement.removeChild(childElement);
        } else {
            break;
        }
    }
    // append new child elements
    for (const auto &childElement : iterChildElements(newElement)) {
        oldElement.appendChild(childElement);
    }
}

QXmppOmemoManagerPrivate::QXmppOmemoManagerPrivate(Manager *parent, QXmppOmemoStorage *omemoStorage)
    : q(parent),
      omemoStorage(omemoStorage),
      signedPreKeyPairsRenewalTimer(parent),
      deviceRemovalTimer(parent)
{
}

//
// Initializes the OMEMO library.
//
void ManagerPrivate::initOmemoLibrary()
{
    if (initGlobalContext() &&
        initLocking() &&
        initCryptoProvider()) {
        initStores();
    } else {
        warning(u"OMEMO library could not be initialized"_s);
    }
}

// Initializes the OMEMO library's global context.
//
// Returns whether the initialization succeeded.
bool ManagerPrivate::initGlobalContext()
{
    // "q" is passed as the parameter "user_data" to functions called by
    // the OMEMO library when no explicit "user_data" is set for those
    // functions (e.g., to the lock and unlock functions).
    if (signal_context_create(globalContext.ptrRef(), q) < 0) {
        warning(u"Signal context could not be be created"_s);
        return false;
    }

    return true;
}

// Initializes the OMEMO library's locking functions.
//
// Returns whether the initialization succeeded.
bool ManagerPrivate::initLocking()
{
    const auto lock = [](void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        d->mutex.lock();
    };

    const auto unlock = [](void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        d->mutex.unlock();
    };

    if (signal_context_set_locking_functions(globalContext.get(), lock, unlock) < 0) {
        warning(u"Locking functions could not be set"_s);
        return false;
    }

    return true;
}

// Initializes the OMEMO library's crypto provider.
//
// Returns whether the initialization succeeded.
bool ManagerPrivate::initCryptoProvider()
{
    cryptoProvider = createOmemoCryptoProvider(this);

    if (signal_context_set_crypto_provider(globalContext.get(), &cryptoProvider) < 0) {
        warning(u"Crypto provider could not be set"_s);
        return false;
    }

    return true;
}

// Initializes the OMEMO library's stores.
//
// Returns whether the initialization succeeded.
void ManagerPrivate::initStores()
{
    identityKeyStore = createIdentityKeyStore();
    preKeyStore = createPreKeyStore();
    signedPreKeyStore = createSignedPreKeyStore();
    sessionStore = createSessionStore();

    signal_protocol_store_context_create(storeContext.ptrRef(), globalContext.get());
    signal_protocol_store_context_set_identity_key_store(storeContext.get(), &identityKeyStore);
    signal_protocol_store_context_set_pre_key_store(storeContext.get(), &preKeyStore);
    signal_protocol_store_context_set_signed_pre_key_store(storeContext.get(), &signedPreKeyStore);
    signal_protocol_store_context_set_session_store(storeContext.get(), &sessionStore);
}

// Creates the OMEMO library's identity key store.
//
// The identity key is the long-term key.
//
// Returns the identity key store.
signal_protocol_identity_key_store ManagerPrivate::createIdentityKeyStore() const
{
    signal_protocol_identity_key_store store;

    store.get_identity_key_pair = [](signal_buffer **public_data, signal_buffer **private_data, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();

        const auto &privateIdentityKey = d->ownDevice.privateIdentityKey;
        if (!(*private_data = signal_buffer_create(reinterpret_cast<const uint8_t *>(privateIdentityKey.constData()), privateIdentityKey.size()))) {
            manager->warning(u"Private identity key could not be loaded"_s);
            return -1;
        }

        const auto &publicIdentityKey = d->ownDevice.publicIdentityKey;
        if (!(*public_data = signal_buffer_create(reinterpret_cast<const uint8_t *>(publicIdentityKey.constData()), publicIdentityKey.size()))) {
            manager->warning(u"Public identity key could not be loaded"_s);
            return -1;
        }

        return 0;
    };

    store.get_local_registration_id = [](void *user_data, uint32_t *registration_id) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        *registration_id = d->ownDevice.id;
        return 0;
    };

    store.save_identity = [](const signal_protocol_address *, uint8_t *, size_t, void *) {
        // Do not use the OMEMO library's trust management.
        return 0;
    };

    store.is_trusted_identity = [](const signal_protocol_address *, uint8_t *, size_t, void *) {
        // Do not use the OMEMO library's trust management.
        // All keys are trusted at this level / by the OMEMO library.
        return 1;
    };

    store.destroy_func = [](void *) {
    };

    store.user_data = q;

    return store;
}

// Creates the OMEMO library's signed pre key store.
//
// A signed pre key is used for building a session.
//
// Returns the signed pre key store.
signal_protocol_signed_pre_key_store ManagerPrivate::createSignedPreKeyStore() const
{
    signal_protocol_signed_pre_key_store store;

    store.load_signed_pre_key = [](signal_buffer **record, uint32_t signed_pre_key_id, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        const auto &signedPreKeyPair = d->signedPreKeyPairs.value(signed_pre_key_id).data;

        if (signedPreKeyPair.isEmpty()) {
            return SG_ERR_INVALID_KEY_ID;
        }

        if (!(*record = signal_buffer_create(reinterpret_cast<const uint8_t *>(signedPreKeyPair.constData()), signedPreKeyPair.size()))) {
            manager->warning(u"Signed pre key pair could not be loaded"_s);
            return SG_ERR_INVALID_KEY_ID;
        }

        return SG_SUCCESS;
    };

    store.store_signed_pre_key = [](uint32_t signed_pre_key_id, uint8_t *record, size_t record_len, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();

        QXmppOmemoStorage::SignedPreKeyPair signedPreKeyPair;
        signedPreKeyPair.creationDate = QDateTime::currentDateTimeUtc();
        signedPreKeyPair.data = QByteArray(reinterpret_cast<const char *>(record), record_len);

        d->signedPreKeyPairs.insert(signed_pre_key_id, signedPreKeyPair);
        d->omemoStorage->addSignedPreKeyPair(signed_pre_key_id, signedPreKeyPair);

        return 0;
    };

    store.contains_signed_pre_key = [](uint32_t signed_pre_key_id, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        return d->signedPreKeyPairs.contains(signed_pre_key_id) ? 1 : 0;
    };

    store.remove_signed_pre_key = [](uint32_t signed_pre_key_id, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        d->signedPreKeyPairs.remove(signed_pre_key_id);
        d->omemoStorage->removeSignedPreKeyPair(signed_pre_key_id);
        return 0;
    };

    store.destroy_func = [](void *) {
    };

    store.user_data = q;

    return store;
}

// Creates the OMEMO library's pre key store.
//
// A pre key is used for building a session.
//
// Returns the pre key store.
signal_protocol_pre_key_store ManagerPrivate::createPreKeyStore() const
{
    signal_protocol_pre_key_store store;

    store.load_pre_key = [](signal_buffer **record, uint32_t pre_key_id, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        const auto &preKey = d->preKeyPairs.value(pre_key_id);

        if (preKey.isEmpty()) {
            return SG_ERR_INVALID_KEY_ID;
        }

        if (!(*record = signal_buffer_create(reinterpret_cast<const uint8_t *>(preKey.constData()), preKey.size()))) {
            manager->warning(u"Pre key could not be loaded"_s);
            return SG_ERR_INVALID_KEY_ID;
        }

        return SG_SUCCESS;
    };

    store.store_pre_key = [](uint32_t pre_key_id, uint8_t *record, size_t record_len, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        const auto preKey = QByteArray(reinterpret_cast<const char *>(record), record_len);
        d->preKeyPairs.insert(pre_key_id, preKey);
        d->omemoStorage->addPreKeyPairs({ { pre_key_id, preKey } });
        return 0;
    };

    store.contains_pre_key = [](uint32_t pre_key_id, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        return d->preKeyPairs.contains(pre_key_id) ? 1 : 0;
    };

    store.remove_pre_key = [](uint32_t pre_key_id, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();

        if (!d->renewPreKeyPairs(pre_key_id)) {
            return -1;
        }

        return 0;
    };

    store.destroy_func = [](void *) {
    };

    store.user_data = q;

    return store;
}

// Creates the OMEMO library's session store.
//
// A session contains all data needed for encryption and decryption.
//
// Returns the session store.
signal_protocol_session_store ManagerPrivate::createSessionStore() const
{
    signal_protocol_session_store store;

    store.load_session_func = [](signal_buffer **record, signal_buffer **, const signal_protocol_address *address, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        const auto jid = extractJid(*address);

        const auto &session = d->devices.value(jid).value(uint32_t(address->device_id)).session;

        if (session.isEmpty()) {
            return 0;
        }

        if (!(*record = signal_buffer_create(reinterpret_cast<const uint8_t *>(session.constData()), size_t(session.size())))) {
            manager->warning(u"Session could not be loaded"_s);
            return -1;
        }

        return 1;
    };

    store.get_sub_device_sessions_func = [](signal_int_list **sessions, const char *name, size_t name_len, void *user_data) {
        auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        const auto jid = QString::fromUtf8(name, name_len);
        auto userDevices = d->devices.value(jid);

        // Remove all devices not having an active session.
        for (auto itr = userDevices.begin(); itr != userDevices.end();) {
            const auto &device = itr.value();
            if (device.session.isEmpty() || device.unrespondedSentStanzasCount == UNRESPONDED_STANZAS_UNTIL_ENCRYPTION_IS_STOPPED) {
                itr = userDevices.erase(itr);
            } else {
                ++itr;
            }
        }

        signal_int_list *deviceIds = signal_int_list_alloc();
        for (auto itr = userDevices.cbegin(); itr != userDevices.cend(); ++itr) {
            const auto deviceId = itr.key();
            if (signal_int_list_push_back(deviceIds, int(deviceId)) < 0) {
                manager->warning(u"Device ID could not be added to list"_s);
                return -1;
            }
        }

        *sessions = deviceIds;
        return int(signal_int_list_size(*sessions));
    };

    store.store_session_func = [](const signal_protocol_address *address, uint8_t *record, size_t record_len, uint8_t *, size_t, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        const auto session = QByteArray(reinterpret_cast<const char *>(record), record_len);
        const auto jid = extractJid(*address);
        const auto deviceId = int(address->device_id);

        auto &device = d->devices[jid][deviceId];
        device.session = session;
        d->omemoStorage->addDevice(jid, deviceId, device);
        return 0;
    };

    store.contains_session_func = [](const signal_protocol_address *address, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        const auto *d = manager->d.get();
        const auto jid = extractJid(*address);
        return d->devices.value(jid).value(int(address->device_id)).session.isEmpty() ? 0 : 1;
    };

    store.delete_session_func = [](const signal_protocol_address *address, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        const auto jid = extractJid(*address);
        const auto deviceId = int(address->device_id);
        auto &device = d->devices[jid][deviceId];
        if (!device.session.isEmpty()) {
            device.session.clear();
            d->omemoStorage->addDevice(jid, deviceId, device);
        }
        return 1;
    };

    store.delete_all_sessions_func = [](const char *name, size_t name_len, void *user_data) {
        const auto *manager = reinterpret_cast<Manager *>(user_data);
        auto *d = manager->d.get();
        const auto jid = QString::fromUtf8(name, name_len);
        auto deletedSessionsCount = 0;
        auto &userDevices = d->devices[jid];
        for (auto itr = userDevices.begin(); itr != userDevices.end(); ++itr) {
            const auto &deviceId = itr.key();
            auto &device = itr.value();
            if (!device.session.isEmpty()) {
                device.session.clear();
                d->omemoStorage->addDevice(jid, deviceId, device);
                ++deletedSessionsCount;
            }
        }
        return deletedSessionsCount;
    };

    store.destroy_func = [](void *) {
    };

    store.user_data = q;

    return store;
}

// Sets up the device ID.
//
// The more devices a user has, the higher the possibility of duplicate device IDs is.
// Especially for IoT scenarios with millions of devices, that can be an issue.
// Therefore, a new device ID is generated in case of a duplicate.
//
// Returns whether it succeeded.
QXmppTask<bool> ManagerPrivate::setUpDeviceId()
{
    auto result = co_await pubSubManager->requestOwnPepItemIds(staticString(ns_omemo_2_bundles)).withContext(q);
    // There can be the following cases:
    // 1. There is no PubSub node for device bundles: XEP-0030 states that a server must
    // respond with an error (at least ejabberd 22.05 responds with an empty node instead).
    // 2. There is an empty PubSub node for device bundles: XEP-0030 states that a server must
    // respond with a node without included items.
    auto error = std::get_if<QXmppError>(&result);
    if (error) {
        if (auto stanzaErr = error->value<QXmppStanza::Error>()) {
            // allow Cancel|ItemNotFound here
            if (!(stanzaErr->type() == Error::Cancel && stanzaErr->condition() == Error::ItemNotFound)) {
                warning(u"Existing / Published device IDs could not be retrieved: " + errorToString(*error));
                co_return false;
            }
            // do not return here
        } else {
            co_return false;
        }
    }

    // The first generated device ID can be used if no device bundle node exists.
    // Otherwise, duplicates must be avoided.
    auto deviceId = error ? generateDeviceId() : generateDeviceId(std::get<QList<QString>>(result));
    if (deviceId) {
        ownDevice.id = *deviceId;
    }
    co_return deviceId.has_value();
}

//
// Generates a new device ID.
//
// Returns the device ID or an empty optional on errors.
//
std::optional<uint32_t> QXmppOmemoManagerPrivate::generateDeviceId()
{
    uint32_t deviceId = 0;
    if (signal_protocol_key_helper_generate_registration_id(&deviceId, 0, globalContext.get()) < 0) {
        warning(u"Device ID could not be generated"_s);
        return {};
    }
    return deviceId;
}

//
// Generates a new device ID that does not exist yet.
//
// Returns the device ID or an empty optional on errors.
//
std::optional<uint32_t> QXmppOmemoManagerPrivate::generateDeviceId(const QList<QString> &existingIds)
{
    uint32_t deviceId = 0;

    do {
        if (signal_protocol_key_helper_generate_registration_id(&deviceId, 0, globalContext.get()) < 0) {
            warning(u"Device ID could not be generated"_s);
            return {};
        }
    } while (existingIds.contains(QString::number(deviceId)));

    return deviceId;
}

// Sets up an identity key pair.
//
// The identity key pair consists of a private and a public long-term key.
//
// Returns whether it succeeded.
bool ManagerPrivate::setUpIdentityKeyPair(ratchet_identity_key_pair **identityKeyPair)
{
    if (signal_protocol_key_helper_generate_identity_key_pair(identityKeyPair, globalContext.get()) < 0) {
        warning(u"Identity key pair could not be generated"_s);
        return false;
    }

    BufferSecurePtr privateIdentityKeyBuffer;

    if (ec_private_key_serialize(privateIdentityKeyBuffer.ptrRef(), ratchet_identity_key_pair_get_private(*identityKeyPair)) < 0) {
        warning(u"Private identity key could not be serialized"_s);
        return false;
    }

    const auto privateIdentityKey = privateIdentityKeyBuffer.toByteArray();
    ownDevice.privateIdentityKey = privateIdentityKey;

    BufferPtr publicIdentityKeyBuffer(ec_public_key_get_ed(ratchet_identity_key_pair_get_public(*identityKeyPair)));
    const auto publicIdentityKey = publicIdentityKeyBuffer.toByteArray();
    deviceBundle.setPublicIdentityKey(publicIdentityKey);
    ownDevice.publicIdentityKey = publicIdentityKey;
    storeOwnKey();

    return true;
}

//
// Schedules periodic (time-based) tasks that cannot be done on a specific event.
//
void ManagerPrivate::schedulePeriodicTasks()
{
    QObject::connect(&signedPreKeyPairsRenewalTimer, &QTimer::timeout, q, [this]() mutable {
        renewSignedPreKeyPairs();
    });

    QObject::connect(&deviceRemovalTimer, &QTimer::timeout, q, [this]() mutable {
        removeDevicesRemovedFromServer();
    });

    signedPreKeyPairsRenewalTimer.start(SIGNED_PRE_KEY_RENEWAL_CHECK_INTERVAL);
    deviceRemovalTimer.start(DEVICE_REMOVAL_CHECK_INTERVAL);
}

//
// Removes old signed pre key pairs and creates a new one.
//
void ManagerPrivate::renewSignedPreKeyPairs()
{
    const auto currentDate = QDateTime::currentDateTimeUtc().toSecsSinceEpoch() * 1s;
    auto isSignedPreKeyPairRemoved = false;

    for (auto itr = signedPreKeyPairs.begin(); itr != signedPreKeyPairs.end();) {
        const auto creationDate = itr.value().creationDate.toSecsSinceEpoch() * 1s;

        // Remove signed pre key pairs older than
        // SIGNED_PRE_KEY_RENEWAL_INTERVAL.
        if (currentDate - creationDate > SIGNED_PRE_KEY_RENEWAL_INTERVAL) {
            omemoStorage->removeSignedPreKeyPair(itr.key());
            itr = signedPreKeyPairs.erase(itr);
            isSignedPreKeyPairRemoved = true;
        } else {
            ++itr;
        }
    }

    if (isSignedPreKeyPairRemoved) {
        RefCountedPtr<ratchet_identity_key_pair> identityKeyPair;
        deserializeIdentityKeyPair(identityKeyPair.ptrRef());
        updateSignedPreKeyPair(identityKeyPair.get());

        // Store the own device containing the new signed pre key ID.
        omemoStorage->setOwnDevice(ownDevice);

        publishDeviceBundleItem().then(q, [this](bool isPublished) {
            if (!isPublished) {
                warning(u"Own device bundle item could not be published during renewal of signed pre key pairs"_s);
            }
        });
    }
}

// Updates the signed pre key pairs.
//
// Make sure that
// \code
// d->omemoStorage->setOwnDevice(d->ownDevice);
// \endcode
// is called afterwards to store the change of
// \code
// d->ownDevice.latestSignedPreKeyId()
// \endcode
// .
//
// Returns whether it succeeded.
bool ManagerPrivate::updateSignedPreKeyPair(ratchet_identity_key_pair *identityKeyPair)
{
    RefCountedPtr<session_signed_pre_key> signedPreKeyPair;
    auto latestSignedPreKeyId = ownDevice.latestSignedPreKeyId;

    // Ensure that no signed pre key ID exceeds SIGNED_PRE_KEY_ID_MAX
    // Do not increment during setup.
    if (latestSignedPreKeyId + 1 > SIGNED_PRE_KEY_ID_MAX) {
        latestSignedPreKeyId = SIGNED_PRE_KEY_ID_MIN;
    } else if (latestSignedPreKeyId != SIGNED_PRE_KEY_ID_MIN) {
        ++latestSignedPreKeyId;
    }

    if (signal_protocol_key_helper_generate_signed_pre_key(
            signedPreKeyPair.ptrRef(),
            identityKeyPair,
            latestSignedPreKeyId,
            uint64_t(QDateTime::currentMSecsSinceEpoch()),
            globalContext.get()) < 0) {
        warning(u"Signed pre key pair could not be generated"_s);
        return false;
    }

    BufferSecurePtr signedPreKeyPairBuffer;

    if (session_signed_pre_key_serialize(signedPreKeyPairBuffer.ptrRef(), signedPreKeyPair.get()) < 0) {
        warning(u"Signed pre key pair could not be serialized"_s);
        return false;
    }

    QXmppOmemoStorage::SignedPreKeyPair signedPreKeyPairForStorage;
    signedPreKeyPairForStorage.creationDate = QDateTime::currentDateTimeUtc();
    signedPreKeyPairForStorage.data = signedPreKeyPairBuffer.toByteArray();

    signedPreKeyPairs.insert(latestSignedPreKeyId, signedPreKeyPairForStorage);
    omemoStorage->addSignedPreKeyPair(latestSignedPreKeyId, signedPreKeyPairForStorage);

    BufferPtr signedPublicPreKeyBuffer(ec_public_key_get_mont(ec_key_pair_get_public(session_signed_pre_key_get_key_pair(signedPreKeyPair.get()))));
    const auto signedPublicPreKeyByteArray = signedPublicPreKeyBuffer.toByteArray();

    deviceBundle.setSignedPublicPreKeyId(latestSignedPreKeyId);
    deviceBundle.setSignedPublicPreKey(signedPublicPreKeyByteArray);
    deviceBundle.setSignedPublicPreKeySignature(QByteArray(reinterpret_cast<const char *>(session_signed_pre_key_get_signature_omemo(signedPreKeyPair.get())), session_signed_pre_key_get_signature_omemo_len(signedPreKeyPair.get())));

    ownDevice.latestSignedPreKeyId = latestSignedPreKeyId;

    return true;
}

// Deletes a pre key pair and creates a new one.
//
// \a keyPairBeingRenewed is key pair being replaced by a new one.
//
// Returns whether it succeeded.
bool ManagerPrivate::renewPreKeyPairs(uint32_t keyPairBeingRenewed)
{
    preKeyPairs.remove(keyPairBeingRenewed);
    omemoStorage->removePreKeyPair(keyPairBeingRenewed);
    deviceBundle.removePublicPreKey(keyPairBeingRenewed);

    if (!updatePreKeyPairs()) {
        return false;
    }

    // Store the own device containing the new pre key ID.
    omemoStorage->setOwnDevice(ownDevice);

    publishDeviceBundleItem().then(q, [this](bool isPublished) {
        if (!isPublished) {
            warning(u"Own device bundle item could not be published during renewal of pre key pairs"_s);
        }
    });

    return true;
}

// Updates the pre key pairs locally.
//
// Make sure that
// \code
// d->omemoStorage->setOwnDevice(d->ownDevice)
// \endcode
// is called
// afterwards to store the change of
// \code
// d->ownDevice.latestPreKeyId()
// \endcode
// .
//
// \a count is number of pre key pairs to update.
//
// Returns whether it succeeded.
bool ManagerPrivate::updatePreKeyPairs(uint32_t count)
{
    KeyListNodePtr newPreKeyPairs;
    auto latestPreKeyId = ownDevice.latestPreKeyId;

    // Ensure that no pre key ID exceeds PRE_KEY_ID_MAX.
    // Do not increment during setup.
    if (latestPreKeyId + count > PRE_KEY_ID_MAX) {
        latestPreKeyId = PRE_KEY_ID_MIN;
    } else if (latestPreKeyId != PRE_KEY_ID_MIN) {
        ++latestPreKeyId;
    }

    if (signal_protocol_key_helper_generate_pre_keys(newPreKeyPairs.ptrRef(), latestPreKeyId, count, globalContext.get()) < 0) {
        warning(u"Pre key pairs could not be generated"_s);
        return false;
    }

    QHash<uint32_t, QByteArray> serializedPreKeyPairs;

    for (auto *node = newPreKeyPairs.get();
         node != nullptr;
         node = signal_protocol_key_helper_key_list_next(node)) {
        BufferSecurePtr preKeyPairBuffer;

        auto preKeyPair = signal_protocol_key_helper_key_list_element(node);

        if (session_pre_key_serialize(preKeyPairBuffer.ptrRef(), preKeyPair) < 0) {
            warning(u"Pre key pair could not be serialized"_s);
            return false;
        }

        const auto preKeyId = session_pre_key_get_id(preKeyPair);

        serializedPreKeyPairs.insert(preKeyId, preKeyPairBuffer.toByteArray());

        BufferPtr publicPreKeyBuffer(ec_public_key_get_mont(ec_key_pair_get_public(session_pre_key_get_key_pair(preKeyPair))));
        const auto serializedPublicPreKey = publicPreKeyBuffer.toByteArray();
        deviceBundle.addPublicPreKey(preKeyId, serializedPublicPreKey);
    }

    preKeyPairs.insert(serializedPreKeyPairs);
    omemoStorage->addPreKeyPairs(serializedPreKeyPairs);
    ownDevice.latestPreKeyId = latestPreKeyId - 1 + count;

    return true;
}

//
// Removes locally stored devices after a specific time if they are removed from their owners'
// device lists on their servers.
//
void ManagerPrivate::removeDevicesRemovedFromServer()
{
    const auto currentDate = QDateTime::currentDateTimeUtc().toSecsSinceEpoch() * 1s;

    for (auto itr = devices.begin(); itr != devices.end(); ++itr) {
        const auto &jid = itr.key();
        auto &userDevices = itr.value();

        for (auto devicesItr = userDevices.begin(); devicesItr != userDevices.end();) {
            const auto &deviceId = devicesItr.key();
            const auto &device = devicesItr.value();

            // Remove data for devices removed from their servers after
            // DEVICE_REMOVAL_INTERVAL.
            const auto &removalDate = device.removalFromDeviceListDate;
            if (!removalDate.isNull() &&
                currentDate - removalDate.toSecsSinceEpoch() * 1s > DEVICE_REMOVAL_INTERVAL) {
                devicesItr = userDevices.erase(devicesItr);
                omemoStorage->removeDevice(jid, deviceId);
                trustManager->removeKeys(staticString(ns_omemo_2), QList { device.keyId });
                Q_EMIT q->deviceRemoved(jid, deviceId);
            } else {
                ++devicesItr;
            }
        }
    }
}

// Encrypts a message for specific recipients.
//
// \a message is message to be encrypted. \a recipientJids is JIDs for whom the message is
// encrypted. \a acceptedTrustLevels is trust levels the keys of the recipients' devices must
// have to encrypt for them.
//
// Returns the result of the encryption.
QXmppTask<QXmppE2eeExtension::MessageEncryptResult> ManagerPrivate::encryptMessageForRecipients(QXmppMessage &&messageRef, QList<QString> recipientJids, TrustLevels acceptedTrustLevels)
{
    // Move into local to prevent use-after-free: rvalue reference parameters
    // dangle after co_await because the coroutine frame only stores the reference.
    auto message = std::move(messageRef);

    if (!initialized) {
        co_return QXmppError {
            u"OMEMO manager must be initialized before encrypting"_s,
            SendError::EncryptionError
        };
    }
    recipientJids.append(ownBareJid());

    auto omemoElement = co_await encryptStanza(message, recipientJids, acceptedTrustLevels);
    if (!omemoElement) {
        co_return QXmppError {
            u"OMEMO element could not be created"_s,
            QXmpp::SendError::EncryptionError,
        };
    }

    // Messages with a body or trust messages use
    // \xep{0380}{Explicit Message Encryption} and a fallback body.
    //
    // In the former case, a client can display the fallback body to its user if it does
    // not support the used encrpytion.
    // Furthermore, a message processing hint for instructing the server to store the
    // message is not needed because of the unencrypted (i.e., public) fallback body.
    // Without a public (fallback) body and a message processing hint, the server could
    // not determine whether the message should be stored because the encrypted body
    // would not be visible to the server.
    //
    // In the latter case, a trust message could otherwise be detected by an attacker.
    // By applying the same rules as for a message with a body, the trust message looks
    // like a normal message.
    // An attacker can therefore either stop all communication or none.
    // But the attacker cannot prevent the chat partners from authenticating their keys
    // while allowing them to exchange encrypted messages that can be read by an active
    // attack.
    //
    // Whether to advise the server to store other kinds of messages is up to the
    // client.
    // That facilitates a consistent handling of message processing hints.

    // reset fallback markers: they are serialized in both public and private modes,
    // so this is needed to avoid leaking sensitive content
    message.setFallbackMarkers({});

    if (!message.body().isEmpty() || message.trustMessageElement()) {
        QXmppFallback fallback { staticString(ns_omemo_2), { { QXmppFallback::Body, {} } } };

        message.setEncryptionMethod(QXmpp::Omemo2);
        message.setE2eeFallbackBody(u"This message is encrypted with %1 but could not be decrypted"_s.arg(message.encryptionName()));
        message.setFallbackMarkers({ fallback });
    }

    message.setOmemoElement(omemoElement);

    co_return std::make_unique<QXmppMessage>(std::move(message));
}

// Encrypts a message or IQ stanza.
//
// \a stanza is stanza to be encrypted. \a recipientJids is JIDs of the devices for whom the
// stanza is encrypted. \a acceptedTrustLevels is trust levels the keys of the recipients'
// devices must have to encrypt for them.
//
// Returns the OMEMO element containing the stanza's encrypted content if the encryption is
// successful, otherwise none.
template<typename T>
QXmppTask<std::optional<QXmppOmemoElement>> ManagerPrivate::encryptStanza(const T &stanza, const QList<QString> &recipientJids, TrustLevels acceptedTrustLevels)
{
    Q_ASSERT_X(!recipientJids.isEmpty(), "Creating OMEMO envelope", "OMEMO element could not be created because no recipient JIDs are passed");

    auto interface = std::make_shared<QXmppPromise<std::optional<QXmppOmemoElement>>>();
    auto task = interface->task();

    if (const auto optionalPayloadEncryptionResult = encryptPayload(createSceEnvelope(stanza))) {
        const auto &payloadEncryptionResult = *optionalPayloadEncryptionResult;

        auto devicesCount = std::accumulate(recipientJids.cbegin(), recipientJids.cend(), 0, [&](const auto sum, const auto &jid) {
            return sum + devices.value(jid).size();
        });

        // Do not exceed the maximum of manageable devices.
        if (devicesCount > maximumDevicesPerStanza) {
            warning(u"OMEMO payload could not be encrypted for all recipients because their "
                    "devices are altogether more than the maximum of manageable devices " +
                    QString::number(maximumDevicesPerStanza) +
                    u" - Use QXmppOmemoManager::setMaximumDevicesPerStanza() to increase the maximum");
            devicesCount = maximumDevicesPerStanza;
        }

        if (devicesCount) {
            const auto ownJid = ownBareJid();

            // Whether the stanza is encrypted for at least one device of a JID other than the
            // own one. Encrypting only for the own devices (e.g., a note to self) is still a
            // success, but if there are actual recipients, the encryption must succeed for at
            // least one of their devices.
            const auto hasNonOwnRecipient = std::ranges::any_of(recipientJids, [&](const auto &jid) {
                return jid != ownJid;
            });

            auto omemoElement = std::make_shared<QXmppOmemoElement>();
            auto processedDevicesCount = std::make_shared<int>(0);
            auto successfullyProcessedDevicesCount = std::make_shared<int>(0);
            auto successfullyProcessedRecipientDevicesCount = std::make_shared<int>(0);
            auto skippedDevicesCount = std::make_shared<int>(0);

            // Add envelopes for all devices of the recipients.
            for (const auto &jid : recipientJids) {
                auto recipientDevices = devices.value(jid);

                for (auto itr = recipientDevices.begin(); itr != recipientDevices.end(); ++itr) {
                    const auto &deviceId = itr.key();
                    const auto &device = itr.value();

                    auto controlDeviceProcessing = [=, this](bool isSuccessful = true) mutable {
                        if (isSuccessful) {
                            ++(*successfullyProcessedDevicesCount);

                            if (jid != ownJid) {
                                ++(*successfullyProcessedRecipientDevicesCount);
                            }
                        }

                        if (++(*processedDevicesCount) == devicesCount) {
                            // The encryption is only successful if an envelope was created for at
                            // least one device of an actual recipient (i.e., not only for the own
                            // devices). Otherwise, the stanza would be sent without the intended
                            // recipients being able to decrypt it.
                            const auto noRecipientDeviceEncrypted = hasNonOwnRecipient
                                ? *successfullyProcessedRecipientDevicesCount == 0
                                : *successfullyProcessedDevicesCount == 0;

                            if (noRecipientDeviceEncrypted) {
                                warning(u"OMEMO element could not be created because no recipient "
                                        u"devices with keys having accepted trust levels could be found"_s);
                                interface->finish(std::nullopt);
                            } else {
                                omemoElement->setSenderDeviceId(ownDevice.id);
                                omemoElement->setPayload(payloadEncryptionResult.encryptedPayload);
                                interface->finish(*omemoElement);
                            }
                        }
                    };

                    // Skip encrypting for a device if it does not respond for a while.
                    if (const auto unrespondedSentStanzasCount = device.unrespondedSentStanzasCount; unrespondedSentStanzasCount == UNRESPONDED_STANZAS_UNTIL_ENCRYPTION_IS_STOPPED) {
                        if (++(*skippedDevicesCount) == devicesCount) {
                            warning(u"OMEMO element could not be created because no recipient device responded to " +
                                    QString::number(unrespondedSentStanzasCount) + u" sent stanzas");
                            interface->finish(std::nullopt);
                        } else {
                            controlDeviceProcessing(false);
                        }

                        continue;
                    }

                    const auto address = Address(jid, deviceId);

                    auto addOmemoEnvelope = [this, payloadEncryptionResult, omemoElement, address, jid, deviceId, controlDeviceProcessing]() mutable {
                        // Create and add an OMEMO envelope only if its data could be created
                        // and the corresponding device has not been removed by another method
                        // in the meantime.
                        if (const auto envelopeData = createOmemoEnvelopeData(address.data(), payloadEncryptionResult.decryptionData); !envelopeData) {
                            warning(u"OMEMO envelope for recipient JID '" + jid + u"' and device ID '" + QString::number(deviceId) + u"' could not be created because its data could not be encrypted");
                            controlDeviceProcessing(false);
                        } else if (devices.value(jid).contains(deviceId)) {
                            auto &deviceBeingModified = devices[jid][deviceId];
                            deviceBeingModified.unrespondedReceivedStanzasCount = 0;

                            if (auto &unrespondedSentStanzasCount = deviceBeingModified.unrespondedSentStanzasCount; unrespondedSentStanzasCount + 1 <= UNRESPONDED_STANZAS_UNTIL_ENCRYPTION_IS_STOPPED) {
                                ++unrespondedSentStanzasCount;
                            }

                            omemoStorage->addDevice(jid, deviceId, deviceBeingModified);

                            QXmppOmemoEnvelope omemoEnvelope;
                            omemoEnvelope.setRecipientDeviceId(deviceId);
                            omemoEnvelope.setUsedForKeyExchange(envelopeData->isKeyExchange);
                            omemoEnvelope.setData(envelopeData->data);
                            omemoElement->addEnvelope(jid, omemoEnvelope);
                            controlDeviceProcessing();
                        }
                    };

                    auto buildSessionDependingOnTrustLevel = [this, jid, deviceId, address, acceptedTrustLevels, controlDeviceProcessing, addOmemoEnvelope](const QXmppOmemoDeviceBundle &deviceBundle, TrustLevel trustLevel) mutable {
                        // Build a session if the device's key has a specific trust level.
                        if (!acceptedTrustLevels.testFlag(trustLevel)) {
                            q->debug(u"Session could not be created for JID '" + jid + u"' with device ID '" + QString::number(deviceId) + u"' because its key's trust level '" + QString::number(int(trustLevel)) + u"' is not accepted");
                            controlDeviceProcessing(false);
                        } else if (!buildSession(address.data(), deviceBundle)) {
                            warning(u"Session could not be created for JID '" + jid + u"' and device ID '" + QString::number(deviceId) + u"'");
                            controlDeviceProcessing(false);
                        } else {
                            addOmemoEnvelope();
                        }
                    };

                    // If the key ID is not stored (empty), the device bundle must be retrieved
                    // first.
                    // Afterwards, the bundle can be used to determine the key's trust level and
                    // to build the session.
                    // If the key ID is stored (not empty), the trust level can be directly
                    // determined and the session built.
                    if (device.keyId.isEmpty()) {
                        auto future = requestDeviceBundle(jid, deviceId);
                        future.then(q, [this, jid, deviceId, buildSessionDependingOnTrustLevel, controlDeviceProcessing](std::optional<QXmppOmemoDeviceBundle> optionalDeviceBundle) mutable {
                            // Process the device bundle only if one could be fetched and the
                            // corresponding device has not been removed by another method in
                            // the meantime.
                            if (optionalDeviceBundle && devices.value(jid).contains(deviceId)) {
                                auto &deviceBeingModified = devices[jid][deviceId];
                                const auto &deviceBundle = *optionalDeviceBundle;
                                deviceBeingModified.keyId = deviceBundle.publicIdentityKey();

                                auto future = q->trustLevel(jid, deviceBeingModified.keyId);
                                future.then(q, [this, jid, deviceId, deviceBeingModified, deviceBundle, buildSessionDependingOnTrustLevel](TrustLevel trustLevel) mutable {
                                    // Store the retrieved key's trust level if it is not stored
                                    // yet.
                                    if (trustLevel == TrustLevel::Undecided) {
                                        auto future = storeKeyDependingOnSecurityPolicy(jid, deviceBeingModified.keyId);
                                        future.then(q, [this, jid, deviceId, deviceBundle, deviceBeingModified, buildSessionDependingOnTrustLevel](TrustLevel trustLevel) mutable {
                                            omemoStorage->addDevice(jid, deviceId, deviceBeingModified);
                                            Q_EMIT q->deviceChanged(jid, deviceId);
                                            buildSessionDependingOnTrustLevel(deviceBundle, trustLevel);
                                        });
                                    } else {
                                        omemoStorage->addDevice(jid, deviceId, deviceBeingModified);
                                        Q_EMIT q->deviceChanged(jid, deviceId);
                                        buildSessionDependingOnTrustLevel(deviceBundle, trustLevel);
                                    }
                                });
                            } else {
                                warning(u"OMEMO envelope could not be created because no device bundle could be fetched"_s);
                                controlDeviceProcessing(false);
                            }
                        });
                    } else {
                        auto future = q->trustLevel(jid, device.keyId);
                        future.then(q, [=, this](TrustLevel trustLevel) mutable {
                            // Create only OMEMO envelopes for devices that have keys with
                            // specific trust levels.
                            if (acceptedTrustLevels.testFlag(trustLevel)) {
                                // Build a new session if none is stored.
                                // Otherwise, use the existing session.
                                if (device.session.isEmpty()) {
                                    auto future = requestDeviceBundle(jid, deviceId);
                                    future.then(q, [=, this](std::optional<QXmppOmemoDeviceBundle> optionalDeviceBundle) mutable {
                                        if (optionalDeviceBundle) {
                                            const auto &deviceBundle = *optionalDeviceBundle;
                                            buildSessionDependingOnTrustLevel(deviceBundle, trustLevel);
                                        } else {
                                            warning(u"OMEMO envelope could not be created because no device bundle could be fetched"_s);
                                            controlDeviceProcessing(false);
                                        }
                                    });
                                } else {
                                    addOmemoEnvelope();
                                }
                            } else {
                                q->debug(u"OMEMO envelope could not be created for JID '" + jid + u"' and device ID '" + QString::number(deviceId) + u"' because the device's key has an unaccepted trust level '" + QString::number(int(trustLevel)) + u"'");
                                controlDeviceProcessing(false);
                            }
                        });
                    }
                }
            }
        } else {
            warning(u"OMEMO element could not be created because no recipient devices could be found"_s);
            interface->finish(std::nullopt);
        }
    } else {
        warning(u"OMEMO payload could not be encrypted"_s);
        interface->finish(std::nullopt);
    }

    return task;
}

template QXmppTask<std::optional<QXmppOmemoElement>> ManagerPrivate::encryptStanza<QXmppIq>(const QXmppIq &, const QList<QString> &, TrustLevels);
template QXmppTask<std::optional<QXmppOmemoElement>> ManagerPrivate::encryptStanza<QXmppMessage>(const QXmppMessage &, const QList<QString> &, TrustLevels);

// Encrypts a payload symmetrically.
//
// \a payload is payload being symmetrically encrypted.
//
// Returns the data used for encryption and the result.
std::optional<PayloadEncryptionResult> ManagerPrivate::encryptPayload(const QByteArray &payload) const
{
    using namespace Crypto;

    auto hkdfKey = SecureByteArray(randomBytes(HKDF_KEY_SIZE));
    const auto hkdfSalt = QByteArray(HKDF_SALT_SIZE, '\0');
    const auto hkdfInfo = QByteArray(HKDF_INFO);
    auto hkdfOutput = hkdfSha256(hkdfKey.toByteArray(), hkdfSalt, hkdfInfo, HKDF_OUTPUT_SIZE);

    if (hkdfOutput.isEmpty()) {
        warning(u"HKDF key derivation failed"_s);
        return {};
    }

    // first part of hkdfOutput
    auto encryptionKey = QByteArray(hkdfOutput.constData(), PAYLOAD_KEY_SIZE);

    // middle part of hkdfOutput
    auto authenticationKey = QByteArray(hkdfOutput.constData() + PAYLOAD_KEY_SIZE, PAYLOAD_AUTHENTICATION_KEY_SIZE);

    // last part of hkdfOutput
    auto initializationVector = QByteArray(hkdfOutput.constData() + PAYLOAD_KEY_SIZE + PAYLOAD_AUTHENTICATION_KEY_SIZE, PAYLOAD_INITIALIZATION_VECTOR_SIZE);

    auto encryptedPayload = aesCbcEncrypt(payload, encryptionKey, initializationVector);

    if (encryptedPayload.isEmpty()) {
        warning(u"Following payload could not be encrypted: " + QString::fromUtf8(payload));
        return {};
    }

    auto messageAuthenticationCode = hmacSha256(authenticationKey, encryptedPayload);
    messageAuthenticationCode.resize(PAYLOAD_MESSAGE_AUTHENTICATION_CODE_SIZE);

    PayloadEncryptionResult payloadEncryptionData;
    payloadEncryptionData.decryptionData = hkdfKey.append(SecureByteArray(messageAuthenticationCode));
    payloadEncryptionData.encryptedPayload = encryptedPayload;

    return payloadEncryptionData;
}

// Creates the SCE envelope as defined in \xep{0420}{Stanza Content Encryption} for a message
// or IQ stanza.
//
// The stanza's content that should be encrypted is put into the SCE content and that is added
// to the SCE envelope.
// Additionally, the standard SCE affix elements are added to the SCE envelope.
//
// \a stanza is stanza for whom the SCE envelope is created.
//
// Returns the serialized SCE envelope.
template<typename T>
QByteArray ManagerPrivate::createSceEnvelope(const T &stanza)
{
    QByteArray serializedSceEnvelope;
    QXmlStreamWriter writer(&serializedSceEnvelope);
    QXmppSceEnvelopeWriter sceEnvelopeWriter(writer);
    sceEnvelopeWriter.start();
    sceEnvelopeWriter.writeTimestamp(QDateTime::currentDateTimeUtc());
    sceEnvelopeWriter.writeTo(QXmppUtils::jidToBareJid(stanza.to()));
    sceEnvelopeWriter.writeFrom(q->client()->configuration().jidBare());
    sceEnvelopeWriter.writeRpad(QString::fromUtf8(generateRandomBytes(SCE_RPAD_SIZE_MIN, SCE_RPAD_SIZE_MAX).toBase64()));
    sceEnvelopeWriter.writeContent([&writer, &stanza] {
        if constexpr (std::is_same_v<T, QXmppMessage>) {
            stanza.serializeExtensions(&writer, SceSensitive, staticString(ns_client));
        } else {
            // If the IQ stanza contains an error (i.e., it is an error response), that error is
            // serialized instead of actual content.
            if (auto err = stanza.errorOptional()) {
                err->toXml(&writer);
            } else {
                stanza.toXmlElementFromChild(&writer);
            }
        }
    });
    sceEnvelopeWriter.end();

    return serializedSceEnvelope;
}

// Creates the data of an OMEMO envelope.
//
// Encrypts the data used for a symmetric encryption of a payload asymmetrically with the
// recipient device's key.
//
// \a address is address of a recipient device. \a payloadDecryptionData is data used for
// symmetric encryption being asymmetrically encrypted.
//
// Returns the encrypted and serialized OMEMO envelope data together with whether it is used for
// key exchange, or std::nullopt on failure.
std::optional<OmemoEnvelopeData> ManagerPrivate::createOmemoEnvelopeData(const signal_protocol_address &address, const Crypto::SecureByteArray &payloadDecryptionData) const
{
    SessionCipherPtr sessionCipher;

    if (session_cipher_create(sessionCipher.ptrRef(), storeContext.get(), &address, globalContext.get()) < 0) {
        warning(u"Session cipher could not be created"_s);
        return std::nullopt;
    }

    session_cipher_set_version(sessionCipher.get(), CIPHERTEXT_OMEMO_VERSION);

    RefCountedPtr<ciphertext_message> encryptedOmemoEnvelopeData;
    if (session_cipher_encrypt(sessionCipher.get(), reinterpret_cast<const uint8_t *>(payloadDecryptionData.constData()), payloadDecryptionData.size(), encryptedOmemoEnvelopeData.ptrRef()) != SG_SUCCESS) {
        warning(u"Payload decryption data could not be encrypted"_s);
        return std::nullopt;
    }

    signal_buffer *serializedEncryptedOmemoEnvelopeData = ciphertext_message_get_serialized(encryptedOmemoEnvelopeData.get());

    // Whether the envelope is used for key exchange (i.e., the 'kex' attribute) must reflect the
    // actual type of the produced ciphertext message instead of an application-level assumption.
    // The OMEMO library keeps producing pre key messages until it processes a response from the
    // recipient, even when a session record already exists locally.
    return OmemoEnvelopeData {
        omemoLibBufferToByteArray(serializedEncryptedOmemoEnvelopeData),
        ciphertext_message_get_type(encryptedOmemoEnvelopeData.get()) == CIPHERTEXT_PREKEY_TYPE,
    };
}

// Decrypts a message stanza.
//
// In case of an empty (i.e., without payload) OMEMO message for session initiation, only the
// dummy payload's decryption data is decrypted but no payload.
// In case of a normal OMEMO message (i.e., with payload), the payload is decrypted and set as
// the content (i.e., first child element) of the returned stanza.
//
// \a stanza is message stanza to be decrypted.
//
// Returns the decrypted stanza if it could be decrypted.
QXmppTask<std::optional<QXmppMessage>> ManagerPrivate::decryptMessage(QXmppMessage stanza)
{
    // At this point, the stanza has always an OMEMO element.
    const auto omemoElement = *stanza.omemoElement();

    if (const auto omemoEnvelope = omemoElement.searchEnvelope(ownBareJid(), ownDevice.id)) {
        const auto mixUserJid = stanza.mixUserJid();
        const auto senderJid = mixUserJid.isEmpty() ? QXmppUtils::jidToBareJid(stanza.from()) : mixUserJid;
        const auto senderDeviceId = omemoElement.senderDeviceId();
        const auto omemoPayload = omemoElement.payload();

        subscribeToNewDeviceLists(senderJid, senderDeviceId);

        // Process empty OMEMO messages sent by a receiver of this device's first OMEMO message
        // for it after building the initial session or sent by devices to build a new session
        // with this device.
        if (omemoPayload.isEmpty()) {
            auto payloadDecryptionData = co_await extractPayloadDecryptionData(senderJid, senderDeviceId, *omemoEnvelope).withContext(q);
            if (!payloadDecryptionData) {
                warning(u"Empty OMEMO message could not be successfully processed"_s);
            } else {
                q->debug(u"Successfully processed empty OMEMO message"_s);
            }
            co_return {};
        }

        if (auto decrypted = co_await decryptStanza(stanza, senderJid, senderDeviceId, *omemoEnvelope, omemoPayload).withContext(q)) {
            // prevent that public fallback markers are used on the private body
            stanza.setFallbackMarkers({});
            stanza.parseExtensions(decrypted->sceContent, SceSensitive);
            // Remove the OMEMO element from the message because it is not needed
            // anymore after decryption.
            stanza.setOmemoElement({});
            stanza.setE2eeMetadata(decrypted->e2eeMetadata);

            co_return stanza;
        }
    }
    co_return {};
}

// Decrypts an IQ stanza.
//
// The payload is decrypted and set as the content (i.e., first child element) of the returned
// stanza.
//
// \a iqElement is DOM element of the IQ stanza to be decrypted. It MUST be an QXmppOmemoIq.
//
// Returns the serialized decrypted stanza if it could be decrypted.
QXmppTask<std::optional<IqDecryptionResult>> ManagerPrivate::decryptIq(QDomElement iqElement)
{
    using Result = std::optional<IqDecryptionResult>;

    QXmppOmemoIq iq;
    iq.parse(iqElement);
    auto omemoElement = iq.omemoElement();

    if (const auto omemoEnvelope = omemoElement.searchEnvelope(ownBareJid(), ownDevice.id)) {
        const auto senderJid = QXmppUtils::jidToBareJid(iq.from());
        const auto senderDeviceId = omemoElement.senderDeviceId();

        subscribeToNewDeviceLists(senderJid, senderDeviceId);

        if (auto result = co_await decryptStanza(iq, senderJid, senderDeviceId, *omemoEnvelope, omemoElement.payload(), false).withContext(q)) {
            auto decryptedElement = iqElement.cloneNode(true).toElement();
            replaceChildElements(decryptedElement, result->sceContent);

            co_return IqDecryptionResult { decryptedElement, result->e2eeMetadata };
        }
        co_return {};
    }
    co_return {};
}

// Decrypts a message or IQ stanza.
//
// In case of an empty (i.e., without payload) OMEMO message for session initiation, only the
// dummy payload decryption data is decrypted but no payload.
// In case of a normal OMEMO stanza (i.e., with payload), the payload is decrypted and set as
// the content (i.e., first child element) of the returned stanza.
//
// \a stanza is message or IQ stanza being decrypted. \a senderJid is JID of the stanza's
// sender. \a senderDeviceId is device ID of the stanza's sender. \a omemoEnvelope is OMEMO
// envelope within the OMEMO element. \a omemoPayload is OMEMO payload within the OMEMO
// element. \a isMessageStanza indicates whether the received stanza is a message stanza.
//
// Returns the result of the decryption if it succeeded.
template<typename T>
QXmppTask<std::optional<DecryptionResult>> ManagerPrivate::decryptStanza(T stanza, QString senderJid, uint32_t senderDeviceId, const QXmppOmemoEnvelope &omemoEnvelope, const QByteArray &omemoPayload, bool isMessageStanza)
{
    auto serializedSceEnvelope = co_await extractSceEnvelope(senderJid, senderDeviceId, omemoEnvelope, omemoPayload, isMessageStanza)
                                     .withContext(q);

    if (serializedSceEnvelope.isEmpty()) {
        warning(u"SCE envelope could not be extracted"_s);
        co_return {};
    }

    QDomDocument document;
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    document.setContent(serializedSceEnvelope, QDomDocument::ParseOption::UseNamespaceProcessing);
#else
    document.setContent(serializedSceEnvelope, true);
#endif
    QXmppSceEnvelopeReader sceEnvelopeReader(document.documentElement());

    if (sceEnvelopeReader.from() != senderJid) {
        q->info(u"Sender '" + senderJid + u"' of stanza does not match SCE 'from' affix element '" + sceEnvelopeReader.from() + u"'");
    }

    if (isMessageStanza) {
        // For messages from group chats, their "from" element corresponds to the SCE affix element "to".
        if (const auto &message = dynamic_cast<const QXmppMessage &>(stanza); message.type() == QXmppMessage::GroupChat && (sceEnvelopeReader.to() != QXmppUtils::jidToBareJid(stanza.from()))) {
            warning(u"Recipient of group chat message does not match SCE affix element '<to/>'"_s);
            co_return {};
        }
    } else if (sceEnvelopeReader.to() != QXmppUtils::jidToBareJid(stanza.to())) {
        q->info(u"Recipient of IQ does not match SCE affix element '<to/>'"_s);
    }

    auto &device = devices[senderJid][senderDeviceId];
    device.unrespondedSentStanzasCount = 0;

    // Send a heartbeat message to the sender if too many stanzas were
    // received responding to none.
    if (device.unrespondedReceivedStanzasCount == UNRESPONDED_STANZAS_UNTIL_HEARTBEAT_MESSAGE_IS_SENT) {
        sendEmptyMessage(senderJid, senderDeviceId);
        device.unrespondedReceivedStanzasCount = 0;
    } else {
        ++device.unrespondedReceivedStanzasCount;
    }

    QXmppE2eeMetadata e2eeMetadata;
    e2eeMetadata.setSceTimestamp(sceEnvelopeReader.timestamp());
    e2eeMetadata.setEncryption(QXmpp::Omemo2);
    const auto &senderDevice = devices.value(senderJid).value(senderDeviceId);
    e2eeMetadata.setSenderKey(senderDevice.keyId);

    co_return DecryptionResult { sceEnvelopeReader.contentElement(), std::move(e2eeMetadata) };
}

// Extracts the SCE envelope from an OMEMO payload.
//
// The data used to encrypt the payload is decrypted and then used to decrypt the payload which
// contains the SCE envelope.
//
// \a senderJid is bare JID of the stanza's sender. \a senderDeviceId is device ID of the
// stanza's sender. \a omemoEnvelope is OMEMO envelope containing the payload decryption data.
// \a omemoPayload is OMEMO payload containing the SCE envelope. \a isMessageStanza is whether
// the received stanza is a message stanza.
//
// Returns the serialized SCE envelope if it could be extracted, otherwise a
// default-constructed byte array.
QXmppTask<QByteArray> ManagerPrivate::extractSceEnvelope(const QString &senderJid, uint32_t senderDeviceId, const QXmppOmemoEnvelope &omemoEnvelope, QByteArray omemoPayload, bool isMessageStanza)
{
    auto payloadDecryptionData =
        co_await extractPayloadDecryptionData(senderJid, senderDeviceId, omemoEnvelope, isMessageStanza)
            .withContext(q);
    if (!payloadDecryptionData) {
        warning(u"Data for decrypting OMEMO payload could not be extracted"_s);
        co_return {};
    }
    co_return decryptPayload(*payloadDecryptionData, omemoPayload);
}

// Extracts the data used to decrypt the OMEMO payload.
//
// Decrypts the the payload decryption data and handles the OMEMO sessions.
//
// \a senderJid is bare JID of the stanza's sender. \a senderDeviceId is device ID of the
// stanza's sender. \a omemoEnvelope is OMEMO envelope containing the payload decryption data.
// \a isMessageStanza indicates whether the received stanza is a message stanza.
//
// Returns the serialized payload decryption data if it could be extracted, otherwise
// std::nullopt.
QXmppTask<std::optional<Crypto::SecureByteArray>> ManagerPrivate::extractPayloadDecryptionData(const QString &senderJid, uint32_t senderDeviceId, QXmppOmemoEnvelope omemoEnvelope, bool isMessageStanza)
{
    SessionCipherPtr sessionCipher;
    const auto address = Address(senderJid, senderDeviceId);
    const auto addressData = address.data();

    if (session_cipher_create(sessionCipher.ptrRef(), storeContext.get(), &addressData, globalContext.get()) < 0) {
        warning(u"Session cipher could not be created"_s);
        co_return {};
    }

    session_cipher_set_version(sessionCipher.get(), CIPHERTEXT_OMEMO_VERSION);

    BufferSecurePtr payloadDecryptionDataBuffer;

    // There are three cases:
    // 1. If the stanza contains key exchange data, a new session is automatically built by the
    // OMEMO library during decryption.
    // 2. If the stanza does not contain key exchange data and there is no existing session, the
    // stanza cannot be decrypted but a new session is built for future communication.
    // 3. If the stanza does not contain key exchange data and there is an existing session,
    // that session is used to decrypt the stanza.
    if (omemoEnvelope.isUsedForKeyExchange()) {
        RefCountedPtr<pre_key_signal_message> omemoEnvelopeData;
        const auto serializedOmemoEnvelopeData = omemoEnvelope.data();

        if (pre_key_signal_message_deserialize_omemo(omemoEnvelopeData.ptrRef(),
                                                     reinterpret_cast<const uint8_t *>(serializedOmemoEnvelopeData.data()),
                                                     serializedOmemoEnvelopeData.size(),
                                                     senderDeviceId,
                                                     globalContext.get()) < 0) {
            warning(u"OMEMO envelope data could not be deserialized"_s);
            co_return {};
        }
        BufferPtr publicIdentityKeyBuffer(ec_public_key_get_ed(pre_key_signal_message_get_identity_key(omemoEnvelopeData.get())));

        const auto key = publicIdentityKeyBuffer.toByteArray();
        if (key.isEmpty()) {
            warning(u"Public Identity key could not be retrieved"_s);
            co_return {};
        }
        auto &device = devices[senderJid][senderDeviceId];
        auto &storedKeyId = device.keyId;

        // Store the key if its ID has changed.
        if (storedKeyId != key) {
            storedKeyId = key;
            omemoStorage->addDevice(senderJid, senderDeviceId, device);
            Q_EMIT q->deviceChanged(senderJid, senderDeviceId);
        }

        // Decrypt the OMEMO envelope data and build a session.
        switch (session_cipher_decrypt_pre_key_signal_message(sessionCipher.get(), omemoEnvelopeData.get(), nullptr, payloadDecryptionDataBuffer.ptrRef())) {
        case SG_ERR_INVALID_MESSAGE:
            warning(u"OMEMO envelope data for key exchange is not valid"_s);
            co_return {};
        case SG_ERR_DUPLICATE_MESSAGE:
            warning(u"OMEMO envelope data for key exchange is already received"_s);
            co_return {};
        case SG_ERR_LEGACY_MESSAGE:
            warning(u"OMEMO envelope data for key exchange format is deprecated"_s);
            co_return {};
        case SG_ERR_INVALID_KEY_ID: {
            const auto preKeyId = QString::number(pre_key_signal_message_get_pre_key_id(omemoEnvelopeData.get()));
            warning(u"Pre key with ID '" + preKeyId + u"' of OMEMO envelope data for key exchange could not be found locally");
            co_return {};
        }
        case SG_ERR_INVALID_KEY:
            warning(u"OMEMO envelope data for key exchange is incorrectly formatted"_s);
            co_return {};
        case SG_ERR_UNTRUSTED_IDENTITY:
            warning(u"Identity key of OMEMO envelope data for key exchange is not trusted by OMEMO library"_s);
            co_return {};
        case SG_SUCCESS:
            // Send an empty message back to the sender in order to notify the sender's
            // device that the session initiation is completed.
            // Do not send an empty message if the received stanza is an IQ stanza
            // because a response is already directly sent.
            if (isMessageStanza) {
                sendEmptyMessage(senderJid, senderDeviceId);
            }

            // Store the key's trust level if it is not stored yet.
            q->trustLevel(senderJid, storedKeyId).then(q, [=, this](TrustLevel trustLevel) mutable {
                if (trustLevel == TrustLevel::Undecided) {
                    storeKeyDependingOnSecurityPolicy(senderJid, key);
                }
            });

            const auto payloadDecryptionDataPointer = signal_buffer_data(payloadDecryptionDataBuffer.get());
            const auto payloadDecryptionDataBufferSize = signal_buffer_len(payloadDecryptionDataBuffer.get());
            auto payloadDecryptionData = Crypto::SecureByteArray(
                reinterpret_cast<const char *>(payloadDecryptionDataPointer), payloadDecryptionDataBufferSize);

            co_return payloadDecryptionData;
        }
        co_return {};
    }

    if (auto &device = devices[senderJid][senderDeviceId]; device.session.isEmpty()) {
        warning(u"Received OMEMO stanza cannot be decrypted because there is no session with "
                "sending device, new session is being built"_s);

        co_await buildSessionWithDeviceBundle(senderJid, senderDeviceId, device);
        co_return {};
    }

    RefCountedPtr<signal_message> omemoEnvelopeData;
    const auto serializedOmemoEnvelopeData = omemoEnvelope.data();

    if (signal_message_deserialize_omemo(omemoEnvelopeData.ptrRef(), reinterpret_cast<const uint8_t *>(serializedOmemoEnvelopeData.data()), serializedOmemoEnvelopeData.size(), globalContext.get()) < 0) {
        warning(u"OMEMO envelope data could not be deserialized"_s);
        co_return {};
    }

    // Decrypt the OMEMO envelope data.
    switch (session_cipher_decrypt_signal_message(sessionCipher.get(), omemoEnvelopeData.get(), nullptr, payloadDecryptionDataBuffer.ptrRef())) {
    case SG_ERR_INVALID_MESSAGE:
        warning(u"OMEMO envelope data is not valid"_s);
        co_return {};
    case SG_ERR_DUPLICATE_MESSAGE:
        warning(u"OMEMO envelope data is already received"_s);
        co_return {};
    case SG_ERR_LEGACY_MESSAGE:
        warning(u"OMEMO envelope data format is deprecated"_s);
        co_return {};
    case SG_ERR_NO_SESSION:
        warning(u"Session for OMEMO envelope data could not be found"_s);
        co_return {};
    case SG_SUCCESS:
        const auto payloadDecryptionDataPointer = signal_buffer_data(payloadDecryptionDataBuffer.get());
        const auto payloadDecryptionDataBufferSize = signal_buffer_len(payloadDecryptionDataBuffer.get());
        auto payloadDecryptionData = Crypto::SecureByteArray(
            reinterpret_cast<const char *>(payloadDecryptionDataPointer), payloadDecryptionDataBufferSize);

        co_return payloadDecryptionData;
    }

    co_return {};
}

// Decrypts the OMEMO payload.
//
// \a payloadDecryptionData is data needed to decrypt the payload. \a payload is payload to be
// decrypted.
//
// Returns the decrypted payload or a default-constructed byte array on failure.
QByteArray ManagerPrivate::decryptPayload(const Crypto::SecureByteArray &payloadDecryptionData, const QByteArray &payload) const
{
    using namespace Crypto;

    auto hkdfKey = SecureByteArray(payloadDecryptionData);
    hkdfKey.resize(HKDF_KEY_SIZE);
    const auto hkdfSalt = QByteArray(HKDF_SALT_SIZE, '\0');
    const auto hkdfInfo = QByteArray(HKDF_INFO);
    auto hkdfOutput = hkdfSha256(hkdfKey.toByteArray(), hkdfSalt, hkdfInfo, HKDF_OUTPUT_SIZE);

    if (hkdfOutput.isEmpty()) {
        warning(u"HKDF key derivation failed"_s);
        return {};
    }

    // first part of hkdfOutput
    auto encryptionKey = QByteArray(hkdfOutput.constData(), PAYLOAD_KEY_SIZE);

    // middle part of hkdfOutput
    auto authenticationKey = QByteArray(hkdfOutput.constData() + PAYLOAD_KEY_SIZE, PAYLOAD_AUTHENTICATION_KEY_SIZE);

    // last part of hkdfOutput
    auto initializationVector = QByteArray(hkdfOutput.constData() + PAYLOAD_KEY_SIZE + PAYLOAD_AUTHENTICATION_KEY_SIZE, PAYLOAD_INITIALIZATION_VECTOR_SIZE);

    auto messageAuthenticationCode = hmacSha256(authenticationKey, payload);
    messageAuthenticationCode.resize(PAYLOAD_MESSAGE_AUTHENTICATION_CODE_SIZE);

    auto expectedMessageAuthenticationCode = payloadDecryptionData.toByteArray().right(PAYLOAD_MESSAGE_AUTHENTICATION_CODE_SIZE);

    if (!constTimeEqual(messageAuthenticationCode, expectedMessageAuthenticationCode)) {
        warning(u"Message authentication code does not match expected one"_s);
        return {};
    }

    auto decryptedPayload = aesCbcDecrypt(payload, encryptionKey, initializationVector);

    if (decryptedPayload.isEmpty()) {
        warning(u"Following payload could not be decrypted: " + QString::fromUtf8(payload));
        return {};
    }

    return decryptedPayload;
}

// Publishes the OMEMO data for this device.
//
// Returns whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishOmemoData()
{
    auto result = co_await pubSubManager->requestOwnPepFeatures().withContext(q);

    if (const auto error = std::get_if<QXmppError>(&result)) {
        warning(u"Features of PEP service '" + ownBareJid() + u"' could not be retrieved: " + errorToString(*error));
        warning(u"Device bundle and device list could not be published"_s);
        co_return false;
    }

    const auto &pepServiceFeatures = std::get<QList<QString>>(result);

    // Check if the PEP service supports publishing items at all and also publishing
    // multiple items.
    // The support for publishing multiple items is needed to publish multiple device
    // bundles to the corresponding node.
    // It is checked here because if that is not possible, the publication of the device
    // element must not be published.
    // TODO: Uncomment the following line and remove the other one once ejabberd released version > 21.12
    // if (pepServiceFeatures.contains(toString60(ns_pubsub_publish)) && pepServiceFeatures.contains(toString60(ns_pubsub_multi_items))) {
    if (pepServiceFeatures.contains(toString60(ns_pubsub_publish))) {
        auto result = co_await pubSubManager->requestOwnPepNodes();
        if (const auto error = std::get_if<QXmppError>(&result)) {
            warning(u"Nodes of JID '" + ownBareJid() + u"' could not be fetched to check if nodes '" + ns_omemo_2_bundles + u"' and '" + ns_omemo_2_devices + u"' exist: " + errorToString(*error));
            warning(u"Device bundle and device list could not be published"_s);
            co_return false;
        } else {
            const auto &nodes = std::get<QList<QString>>(result);

            const auto deviceListNodeExists = nodes.contains(toString60(ns_omemo_2_devices));
            const auto arePublishOptionsSupported = pepServiceFeatures.contains(toString60(ns_pubsub_publish_options));
            const auto isAutomaticCreationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_auto_create));
            const auto isCreationAndConfigurationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_create_and_configure));
            const auto isCreationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_create_nodes));
            const auto isConfigurationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_config_node));

            // The device bundle is published before the device data is published.
            // That way, it ensures that other devices are notified about this new
            // device only after the corresponding device bundle is published.
            bool published = co_await publishDeviceBundle(
                                 nodes.contains(toString60(ns_omemo_2_bundles)),
                                 arePublishOptionsSupported,
                                 isAutomaticCreationSupported,
                                 isCreationAndConfigurationSupported,
                                 isCreationSupported,
                                 isConfigurationSupported,
                                 pepServiceFeatures.contains(toString60(ns_pubsub_config_node_max)))
                                 .withContext(q);

            if (!published) {
                warning(u"Device bundle could not be published"_s);
                co_return false;
            }
            published = co_await publishDeviceElement(deviceListNodeExists,
                                                      arePublishOptionsSupported,
                                                      isAutomaticCreationSupported,
                                                      isCreationAndConfigurationSupported,
                                                      isCreationSupported,
                                                      isConfigurationSupported);

            if (!published) {
                warning(u"Device element could not be published"_s);
            }
            co_return published;
        }
    } else {
        warning(u"Publishing (multiple) items to PEP node '" + ownBareJid() + u"' is not supported");
        warning(u"Device bundle and device list could not be published"_s);
        co_return false;
    }
}

// Publishes this device's bundle.
//
// If no node for device bundles exists, a new one is created.
//
// \a isDeviceBundlesNodeExistent indicates whether the PEP node for device bundles exists. \a
// arePublishOptionsSupported is whether publish options are supported by the PEP service. \a
// isAutomaticCreationSupported is whether the PEP service supports the automatic creation of
// nodes when new items are published. \a isCreationAndConfigurationSupported indicates whether the
// PEP service supports the configuration of nodes during their creation. \a
// isCreationSupported is whether the PEP service supports creating nodes. \a
// isConfigurationSupported is whether the PEP service supports configuring existing nodes. \a
// isConfigNodeMaxSupported is whether the PEP service supports to set the maximum number of
// allowed items per node to the maximum it supports. \a continuation is the function to be called
// with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceBundle(bool isDeviceBundlesNodeExistent,
                                                    bool arePublishOptionsSupported,
                                                    bool isAutomaticCreationSupported,
                                                    bool isCreationAndConfigurationSupported,
                                                    bool isCreationSupported,
                                                    bool isConfigurationSupported,
                                                    bool isConfigNodeMaxSupported)
{
    // Check if the PEP service supports configuration of nodes during publication of items.
    if (arePublishOptionsSupported) {
        if (isAutomaticCreationSupported || isDeviceBundlesNodeExistent) {
            // The supported publish options cannot be determined because they are not announced
            // via Service Discovery.
            // Especially, there is no feature like ns_pubsub_multi_items and no error case
            // specified for the usage of
            // QXmppPubSubNodeConfig::ItemLimit as a publish option.
            // Thus, it simply tries to publish the item with that publish option.
            // If that fails, it tries to manually create and configure the node and publish the
            // item.
            auto published = co_await publishDeviceBundleItemWithOptions();
            if (published) {
                co_return true;
            }

            published = co_await publishDeviceBundleWithoutOptions(isDeviceBundlesNodeExistent,
                                                                   isCreationAndConfigurationSupported,
                                                                   isCreationSupported,
                                                                   // TODO: Uncomment the following line and remove the other one once ejabberd released version > 21.12
                                                                   // isConfigurationSupported,
                                                                   true,
                                                                   isConfigNodeMaxSupported);
            if (!published) {
                q->debug(u"PEP service '" + ownBareJid() + u"' does not support feature '" + ns_pubsub_publish_options + u"' for all publish options, also not '" + ns_pubsub_create_and_configure + u"', '" + ns_pubsub_create_nodes + u"', '" + ns_pubsub_config_node + u"' and the node does not exist");
            }
            co_return published;
        } else if (isCreationSupported) {
            // Create a node manually if the PEP service does not support creation of nodes
            // during publication of items and no node already
            // exists.
            if (!co_await createDeviceBundlesNode().withContext(q)) {
                co_return false;
            }

            // The supported publish options cannot be determined because they are not
            // announced via Service Discovery.
            // Especially, there is no feature like ns_pubsub_multi_items and no error
            // case specified for the usage of QXmppPubSubNodeConfig::ItemLimit as a
            // publish option.
            // Thus, it simply tries to publish the item with that publish option.
            // If that fails, it tries to manually configure the node and publish the
            // item.
            auto published = co_await publishDeviceBundleItemWithOptions();
            if (published) {
                co_return true;
            } else if (isConfigurationSupported) {
                co_return co_await configureNodeAndPublishDeviceBundle(isConfigNodeMaxSupported);
            } else {
                q->debug(u"PEP service '" + ownBareJid() + u"' does not support feature '" + ns_pubsub_publish_options + u"' for all publish options and also not '" + ns_pubsub_config_node + u"'");
                co_return false;
            }
        } else {
            q->debug(u"PEP service '" + ownBareJid() + u"' does not support features '" + ns_pubsub_auto_create + u"', '" + ns_pubsub_create_nodes + u"' and the node does not exist");
            co_return false;
        }
    } else {
        auto published = co_await publishDeviceBundleWithoutOptions(isDeviceBundlesNodeExistent,
                                                                    isCreationAndConfigurationSupported,
                                                                    isCreationSupported,
                                                                    // TODO: Uncomment the following line and remove the other one once ejabberd released version > 21.12
                                                                    // isConfigurationSupported,
                                                                    true,
                                                                    isConfigNodeMaxSupported);
        if (!published) {
            q->debug(u"PEP service '" + ownBareJid() + u"' does not support features '" + ns_pubsub_publish_options + u"', '" + ns_pubsub_create_and_configure + u"', '" + ns_pubsub_create_nodes + u"', '" + ns_pubsub_config_node + u"' and the node does not exist");
        }
        co_return published;
    }
}

// Publish this device's bundle without publish options.
//
// If no node for device bundles exists, a new one is created.
//
// \a isDeviceBundlesNodeExistent indicates whether the PEP node for device bundles exists. \a
// isCreationAndConfigurationSupported is whether the PEP service supports the configuration of
// nodes during their creation. \a isCreationSupported indicates whether the PEP service supports
// creating nodes. \a isConfigurationSupported indicates whether the PEP service supports configuring
// existing nodes. \a isConfigNodeMaxSupported indicates whether the PEP service supports to set the
// maximum number of allowed items per node to the maximum it supports. \a continuation is
// function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceBundleWithoutOptions(bool isDeviceBundlesNodeExistent,
                                                                  bool isCreationAndConfigurationSupported,
                                                                  bool isCreationSupported,
                                                                  bool isConfigurationSupported,
                                                                  bool isConfigNodeMaxSupported)
{
    if (isDeviceBundlesNodeExistent && isConfigurationSupported) {
        co_return co_await configureNodeAndPublishDeviceBundle(isConfigNodeMaxSupported);
    } else if (isCreationAndConfigurationSupported) {
        auto createdAndConfigured = co_await createAndConfigureDeviceBundlesNode(isConfigNodeMaxSupported)
                                        .withContext(q);
        if (createdAndConfigured) {
            co_return co_await publishDeviceBundleItem();
        } else {
            co_return false;
        }
    } else if (isCreationSupported && isConfigurationSupported) {
        auto created = co_await createDeviceBundlesNode();
        if (created) {
            co_return co_await configureNodeAndPublishDeviceBundle(isConfigNodeMaxSupported);
        } else {
            co_return false;
        }
    } else {
        co_return false;
    }
}

// Configures the existing PEP node for device bundles and publishes this device's bundle on it.
//
// \a isConfigNodeMaxSupported indicates whether the PEP service supports to set the maximum number of
// allowed items per node to the maximum it supports. \a continuation is the function to be called
// with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::configureNodeAndPublishDeviceBundle(bool isConfigNodeMaxSupported)
{
    auto configured = co_await configureDeviceBundlesNode(isConfigNodeMaxSupported);
    if (configured) {
        co_return co_await publishDeviceBundleItem();
    }
    co_return false;
}

// Creates a PEP node for device bundles and configures it accordingly.
//
// \a isConfigNodeMaxSupported indicates whether the PEP service supports to set the maximum number of
// allowed items per node to the maximum it supports. \a continuation is the function to be called
// with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::createAndConfigureDeviceBundlesNode(bool isConfigNodeMaxSupported)
{
    if (isConfigNodeMaxSupported) {
        co_return co_await createNode(staticString(ns_omemo_2_bundles), deviceBundlesNodeConfig());
    }

    for (auto maxItems : { PUBSUB_NODE_MAX_ITEMS_1, PUBSUB_NODE_MAX_ITEMS_2, PUBSUB_NODE_MAX_ITEMS_3 }) {
        if (co_await createNode(staticString(ns_omemo_2_bundles), deviceBundlesNodeConfig(maxItems)).withContext(q)) {
            co_return true;
        }
    }
    co_return false;
}

// Creates a PEP node for device bundles.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::createDeviceBundlesNode()
{
    return createNode(staticString(ns_omemo_2_bundles));
}

// Configures an existing PEP node for device bundles.
//
// There is no feature (like ns_pubsub_config_node_max as a config option) and no error case
// specified for the usage of \c QXmppPubSubNodeConfig::Max() as the value for the config
// option \c QXmppPubSubNodeConfig::ItemLimit.
// Thus, it tries to configure the node with that config option's value and if it fails, it
// tries again with pre-defined values.
// Each pre-defined value can exceed the maximum supported by the PEP service.
// Therefore, multiple values are tried.
//
// \a isConfigNodeMaxSupported indicates whether the PEP service supports to set the maximum number of
// allowed items per node to the maximum it supports. \a continuation is the function to be called
// with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::configureDeviceBundlesNode(bool isConfigNodeMaxSupported)
{
    if (isConfigNodeMaxSupported) {
        co_return co_await configureNode(staticString(ns_omemo_2_bundles), deviceBundlesNodeConfig());
    }

    for (auto maxItems : { PUBSUB_NODE_MAX_ITEMS_1, PUBSUB_NODE_MAX_ITEMS_2, PUBSUB_NODE_MAX_ITEMS_3 }) {
        if (co_await configureNode(staticString(ns_omemo_2_bundles), deviceBundlesNodeConfig(maxItems)).withContext(q)) {
            co_return true;
        }
    }
    co_return false;
}

// Publishes this device bundle's item on the corresponding existing PEP node.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceBundleItem()
{
    return publishItem(staticString(ns_omemo_2_bundles), deviceBundleItem());
}

// Publishes this device bundle's item with publish options.
//
// If no node for device bundles exists, a new one is created.
//
// There is no feature (like ns_pubsub_config_node_max as a config option) and no error case
// specified for the usage of \c QXmppPubSubNodeConfig::Max() as the value for the publish
// option \c QXmppPubSubNodeConfig::ItemLimit.
// Thus, it tries to publish the item with that publish option's value and if it fails, it
// tries again with pre-defined values.
// Each pre-defined value can exceed the maximum supported by the PEP service.
// Therefore, multiple values are tried.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceBundleItemWithOptions()
{
    if (co_await publishItem(staticString(ns_omemo_2_bundles), deviceBundleItem(), deviceBundlesNodePublishOptions()).withContext(q)) {
        co_return true;
    }

    for (auto maxItems : { PUBSUB_NODE_MAX_ITEMS_1, PUBSUB_NODE_MAX_ITEMS_2, PUBSUB_NODE_MAX_ITEMS_3 }) {
        if (co_await publishItem(staticString(ns_omemo_2_bundles), deviceBundleItem(), deviceBundlesNodePublishOptions(maxItems)).withContext(q)) {
            co_return true;
        }
    }
    co_return false;
}

// Creates a PEP item for this device's bundle.
//
// Returns this device bundle's item.
QXmppOmemoDeviceBundleItem ManagerPrivate::deviceBundleItem() const
{
    QXmppOmemoDeviceBundleItem item;
    item.setId(QString::number(ownDevice.id));
    item.setDeviceBundle(deviceBundle);

    return item;
}

// Requests a device bundle from a PEP service.
//
// \a deviceOwnerJid is bare JID of the device's owner. \a deviceId is ID of the device whose
// bundle is requested.
//
// Returns the device bundle on success, otherwise a nullptr.
QXmppTask<std::optional<QXmppOmemoDeviceBundle>> ManagerPrivate::requestDeviceBundle(QString deviceOwnerJid, uint32_t deviceId) const
{
    auto result = co_await pubSubManager->requestItem<QXmppOmemoDeviceBundleItem>(deviceOwnerJid, staticString(ns_omemo_2_bundles), QString::number(deviceId))
                      .withContext(q);

    if (const auto error = std::get_if<QXmppError>(&result)) {
        warning(u"Device bundle for JID '" + deviceOwnerJid + u"' and device ID '" + QString::number(deviceId) + u"' could not be retrieved: " + errorToString(*error));
        co_return {};
    }
    const auto &item = std::get<QXmppOmemoDeviceBundleItem>(result);
    co_return item.deviceBundle();
}

// Removes the device bundle for this device or deletes the whole node if it would be empty
// after the retraction.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::deleteDeviceBundle()
{
    if (otherOwnDevices().isEmpty()) {
        return deleteNode(staticString(ns_omemo_2_bundles));
    } else {
        return retractItem(staticString(ns_omemo_2_bundles), ownDevice.id);
    }
}

// Publishes this device's element within the device list.
//
// If no node for the device list exists, a new one is created.
//
// \a isDeviceListNodeExistent indicates whether the PEP node for the device list exists. \a
// arePublishOptionsSupported is whether publish options are supported by the PEP service. \a
// isAutomaticCreationSupported is whether the PEP service supports the automatic creation of
// nodes when new items are published. \a isCreationAndConfigurationSupported indicates whether the
// PEP service supports the configuration of nodes during their creation. \a
// isCreationSupported is whether the PEP service supports creating nodes. \a
// isConfigurationSupported is whether the PEP service supports configuring existing nodes. \a
// continuation is function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceElement(bool isDeviceListNodeExistent,
                                                     bool arePublishOptionsSupported,
                                                     bool isAutomaticCreationSupported,
                                                     bool isCreationAndConfigurationSupported,
                                                     bool isCreationSupported,
                                                     bool isConfigurationSupported)
{
    auto updated = co_await updateOwnDevicesLocally(isDeviceListNodeExistent).withContext(q);

    if (!updated) {
        co_return false;
    }

    // Check if the PEP service supports configuration of nodes during
    // publication of items.
    if (arePublishOptionsSupported) {
        if (isAutomaticCreationSupported || isDeviceListNodeExistent) {
            // The supported publish options cannot be determined because they
            // are not announced via Service Discovery.
            // Thus, it simply tries to publish the item with the specified
            // publish options.
            // If that fails, it tries to manually create and configure the node
            // and publish the item.
            auto published = co_await publishDeviceListItemWithOptions().withContext(q);
            if (published) {
                co_return true;
            }

            published = co_await publishDeviceElementWithoutOptions(isDeviceListNodeExistent,
                                                                    isCreationAndConfigurationSupported,
                                                                    isCreationSupported,
                                                                    // TODO: Uncomment the following line and remove the other one once ejabberd released version > 21.12
                                                                    // isConfigurationSupported);
                                                                    true)
                            .withContext(q);
            if (!published) {
                q->debug(u"PEP service '" + ownBareJid() + u"' does not support feature '" + ns_pubsub_publish_options + u"' for all publish options, also not '" + ns_pubsub_create_and_configure + u"', '" + ns_pubsub_create_nodes + u"', '" + ns_pubsub_config_node + u"' and the node does not exist");
            }
            co_return published;
        } else if (isCreationSupported) {
            // Create a node manually if the PEP service does not support creation of
            // nodes during publication of items and no node already exists.
            auto created = co_await createDeviceListNode().withContext(q);

            if (!created) {
                co_return false;
            }

            // The supported publish options cannot be determined because they
            // are not announced via Service Discovery.
            // Thus, it simply tries to publish the item with the specified
            // publish options.
            // If that fails, it tries to manually configure the node and
            // publish the item.
            auto published = co_await publishDeviceListItemWithOptions();
            if (published) {
                co_return true;
            } else if (isConfigurationSupported) {
                co_return co_await configureNodeAndPublishDeviceElement();
            } else {
                q->debug(u"PEP service '" + ownBareJid() + u"' does not support feature '" + ns_pubsub_publish_options + u"' for all publish options and also not '" + ns_pubsub_config_node + u"'");
                co_return false;
            }

        } else {
            q->debug(u"PEP service '" + ownBareJid() + u"' does not support features '" + ns_pubsub_auto_create + u"', '" + ns_pubsub_create_nodes + u"' and the node does not exist");
            co_return false;
        }
    } else {
        auto published = co_await publishDeviceElementWithoutOptions(isDeviceListNodeExistent,
                                                                     isCreationAndConfigurationSupported,
                                                                     isCreationSupported,
                                                                     // TODO: Uncomment the following line and remove the other one once ejabberd released version > 21.12
                                                                     // isConfigurationSupported);
                                                                     true)
                             .withContext(q);
        if (!published) {
            q->debug(u"PEP service '" + ownBareJid() + u"' does not support features '" + ns_pubsub_publish_options + u"', '" + ns_pubsub_create_and_configure + u"', '" + ns_pubsub_create_nodes + u"', '" + ns_pubsub_config_node + u"' and the node does not exist");
        }
        co_return published;
    }
}

// Publish this device's element without publish options.
//
// If no node for the device list exists, a new one is created.
//
// \a isDeviceListNodeExistent indicates whether the PEP node for the device list exists. \a
// isCreationAndConfigurationSupported is whether the PEP service supports the configuration of
// nodes during their creation. \a isCreationSupported indicates whether the PEP service supports
// creating nodes. \a isConfigurationSupported indicates whether the PEP service supports configuring
// existing nodes. \a continuation is the function to be called with the bool value whether it
// succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceElementWithoutOptions(bool isDeviceListNodeExistent, bool isCreationAndConfigurationSupported, bool isCreationSupported, bool isConfigurationSupported)
{
    if (isDeviceListNodeExistent && isConfigurationSupported) {
        co_return co_await configureNodeAndPublishDeviceElement();
    } else if (isCreationAndConfigurationSupported) {
        auto createdAndConfigured = co_await createAndConfigureDeviceListNode();
        if (createdAndConfigured) {
            co_return co_await publishDeviceListItem(true);
        }
        co_return false;
    } else if (isCreationSupported && isConfigurationSupported) {
        auto created = co_await createDeviceListNode();
        if (!created) {
            co_return false;
        }
        co_return co_await configureNodeAndPublishDeviceElement();
    } else {
        co_return false;
    }
}

// Configures the existing PEP node for the device list and publishes this device's element on
// it.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::configureNodeAndPublishDeviceElement()
{
    auto configured = co_await configureDeviceListNode();
    if (!configured) {
        co_return false;
    }
    co_return co_await publishDeviceListItem(true);
}

// Creates a PEP node for the device list and configures it accordingly.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::createAndConfigureDeviceListNode()
{
    return createNode(staticString(ns_omemo_2_devices), deviceListNodeConfig());
}

// Creates a PEP node for the device list.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::createDeviceListNode()
{
    return createNode(staticString(ns_omemo_2_devices));
}

// Configures an existing PEP node for the device list.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::configureDeviceListNode()
{
    return configureNode(staticString(ns_omemo_2_devices), deviceListNodeConfig());
}

// Publishes the device list item containing this device's element on the corresponding existing
// PEP node.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceListItem(bool addOwnDevice)
{
    return publishItem(staticString(ns_omemo_2_devices), deviceListItem(addOwnDevice));
}

// Publishes the device list item containing this device's element with publish options.
//
// If no node for the device list exists, a new one is created.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::publishDeviceListItemWithOptions()
{
    return publishItem(staticString(ns_omemo_2_devices), deviceListItem(), deviceListNodePublishOptions());
}

// Creates a PEP item for the device list containing this device's element.
//
// Returns the device list item.
QXmppOmemoDeviceListItem ManagerPrivate::deviceListItem(bool addOwnDevice)
{
    QXmppOmemoDeviceList deviceList;

    // Add this device to the device list.
    if (addOwnDevice) {
        QXmppOmemoDeviceElement deviceElement;
        deviceElement.setId(ownDevice.id);
        deviceElement.setLabel(ownDevice.label);
        deviceList.append(deviceElement);
    }

    // Add all remaining own devices to the device list.
    const auto ownDevices = otherOwnDevices();
    for (auto itr = ownDevices.cbegin(); itr != ownDevices.cend(); ++itr) {
        const auto &deviceId = itr.key();
        const auto &device = itr.value();

        QXmppOmemoDeviceElement deviceElement;
        deviceElement.setId(deviceId);
        deviceElement.setLabel(device.label);
        deviceList.append(deviceElement);
    }

    QXmppOmemoDeviceListItem item;
    item.setId(QXmppPubSubManager::standardItemIdToString(QXmppPubSubManager::Current));
    item.setDeviceList(deviceList);

    return item;
}

// Updates the own locally stored devices by requesting the current device list from the own
// PEP service.
//
// \a isDeviceListNodeExistent indicates whether the node for the device list exists. \a continuation
// is function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::updateOwnDevicesLocally(bool isDeviceListNodeExistent)
{
    if (isDeviceListNodeExistent && otherOwnDevices().isEmpty()) {
        auto result = co_await pubSubManager->requestOwnPepItem<QXmppOmemoDeviceListItem>(staticString(ns_omemo_2_devices), QXmppPubSubManager::Current).withContext(q);

        if (const auto error = std::get_if<QXmppError>(&result)) {
            warning(u"Device list for JID '" + ownBareJid() + u"' could not be retrieved and thus not updated: " + errorToString(*error));
            co_return false;
        }
        const auto &deviceListItem = std::get<QXmppOmemoDeviceListItem>(result);
        QList<QXmppOmemoDeviceElement> deviceList = deviceListItem.deviceList();

        if (deviceList.empty()) {
            co_return true;
        }

        // Do not exceed the maximum of manageable devices.
        if (deviceList.size() > maximumDevicesPerJid) {
            warning(u"Received own OMEMO device list could not be stored locally "
                    "completely because the devices are more than the maximum of "
                    "manageable devices " +
                    QString::number(maximumDevicesPerJid) +
                    u" - Use 'QXmppOmemoManager::setMaximumDevicesPerJid()' to "
                    "increase the maximum");
            deviceList = deviceList.mid(0, maximumDevicesPerJid);
        }

        // Store all device elements retrieved from the device list locally as
        // devices.
        // The own device (i.e., a device element in the device list with the same
        // ID as of this device) is skipped.

        removeIf(deviceList, [&](const auto &deviceElement) { return deviceElement.id() == ownDevice.id; });

        // Process devices sequentially to avoid MSVC coroutine ICE with structured bindings
        for (const auto &deviceElement : deviceList) {
            auto &device = devices[ownBareJid()][deviceElement.id()];
            device.label = deviceElement.label();

            co_await omemoStorage->addDevice(ownBareJid(), deviceElement.id(), device).withContext(q);
            co_await buildSessionForNewDevice(ownBareJid(), deviceElement.id(), device).withContext(q);
            Q_EMIT q->deviceAdded(ownBareJid(), deviceElement.id());
        }
    }
    co_return true;
}

// Updates all locally stored devices of a contact.
//
// \a deviceOwnerJid is bare JID of the devices' owner. \a deviceListItems is PEP items that
// may contain a device list.
//
// Returns a found device list item.
std::optional<QXmppOmemoDeviceListItem> QXmppOmemoManagerPrivate::updateContactDevices(const QString &deviceOwnerJid, const QList<QXmppOmemoDeviceListItem> &deviceListItems)
{
    if (deviceListItems.size() > 1) {
        const auto itr = std::find_if(deviceListItems.cbegin(), deviceListItems.cend(), [=](const QXmppOmemoDeviceListItem &item) {
            return item.id() == QXmppPubSubManager::standardItemIdToString(QXmppPubSubManager::Current);
        });

        if (itr != deviceListItems.cend()) {
            updateDevices(deviceOwnerJid, *itr);
            return *itr;
        } else {
            warning(u"Device list for JID '" + deviceOwnerJid + u"' could not be updated because the node contains more than one item but none with the singleton node's specific ID '" + QXmppPubSubManager::standardItemIdToString(QXmppPubSubManager::Current) + u"'");
            handleIrregularDeviceListChanges(deviceOwnerJid);
            return {};
        }
    }

    const auto &item = deviceListItems.constFirst();
    updateDevices(deviceOwnerJid, item);
    return item;
}

// Updates all locally stored devices by a passed device list item.
//
// \a deviceOwnerJid is bare JID of the devices' owner. \a deviceListItem is PEP item
// containing the device list.
void ManagerPrivate::updateDevices(const QString &deviceOwnerJid, const QXmppOmemoDeviceListItem &deviceListItem)
{
    const auto isOwnDeviceListNode = ownBareJid() == deviceOwnerJid;
    QList<QXmppOmemoDeviceElement> deviceList = deviceListItem.deviceList();
    auto isOwnDeviceListIncorrect = false;

    // Do not exceed the maximum of manageable devices.
    if (deviceList.size() > maximumDevicesPerJid) {
        warning(u"Received OMEMO device list of JID '" + deviceOwnerJid + u"' could not be stored locally completely because the devices are more than the "
                                                                          u"maximum of manageable devices " +
                QString::number(maximumDevicesPerJid) + u" - Use 'QXmppOmemoManager::setMaximumDevicesPerJid()' to increase the maximum");
        deviceList = deviceList.mid(0, maximumDevicesPerJid);
    }

    if (isOwnDeviceListNode) {
        QList<uint32_t> deviceIds;

        // Search for inconsistencies in the device list to keep it
        // correct.
        // The following problems are corrected:
        //   * Multiple device elements have the same IDs.
        //   * There is no device element for this device.
        //   * There are device elements with the same ID as this device
        //     but different labels.
        for (auto itr = deviceList.begin(); itr != deviceList.end();) {
            const auto deviceElementId = itr->id();

            if (deviceIds.contains(deviceElementId)) {
                isOwnDeviceListIncorrect = true;
                itr = deviceList.erase(itr);
            } else {
                deviceIds.append(deviceElementId);

                if (itr->id() == ownDevice.id) {
                    if (itr->label() != ownDevice.label) {
                        isOwnDeviceListIncorrect = true;
                    }

                    itr = deviceList.erase(itr);
                } else {
                    ++itr;
                }
            }
        }
    }

    // Set a timestamp for locally stored devices that are removed later if
    // they are not included in the device list (i.e., they were removed
    // by their owner).
    auto &ownerDevices = devices[deviceOwnerJid];
    for (auto itr = ownerDevices.begin(); itr != ownerDevices.end(); ++itr) {
        const auto &deviceId = itr.key();
        auto &device = itr.value();
        auto isDeviceFound = false;

        for (const auto &deviceElement : std::as_const(deviceList)) {
            if (deviceId == deviceElement.id()) {
                isDeviceFound = true;
                break;
            }
        }

        if (!isDeviceFound) {
            device.removalFromDeviceListDate = QDateTime::currentDateTimeUtc();
            omemoStorage->addDevice(deviceOwnerJid, deviceId, device);
        }
    }

    // Update locally stored devices if they are modified in the device
    // list or store devices locally if they are new in the device list.
    for (const auto &deviceElement : std::as_const(deviceList)) {
        auto isDeviceFound = false;

        for (auto itr = ownerDevices.begin(); itr != ownerDevices.end(); ++itr) {
            const auto &deviceId = itr.key();
            auto &device = itr.value();

            if (deviceId == deviceElement.id()) {
                auto isDeviceModified = false;
                auto isDeviceLabelModified = false;

                // Reset the date of removal from server, if it has been
                // removed before.
                if (!device.removalFromDeviceListDate.isNull()) {
                    device.removalFromDeviceListDate = {};
                    isDeviceModified = true;
                }

                // Update the stored label if it differs from the new
                // one.
                if (device.label != deviceElement.label()) {
                    device.label = deviceElement.label();
                    isDeviceModified = true;
                    isDeviceLabelModified = true;
                }

                // Store the modifications.
                if (isDeviceModified) {
                    omemoStorage->addDevice(deviceOwnerJid, deviceId, device);

                    if (isDeviceLabelModified) {
                        Q_EMIT q->deviceChanged(deviceOwnerJid, deviceId);
                    }
                }

                isDeviceFound = true;
                break;
            }
        }

        // Create a new entry and store it if there is no such entry
        // yet.
        if (!isDeviceFound) {
            const auto deviceId = deviceElement.id();
            auto &device = ownerDevices[deviceId];
            device.label = deviceElement.label();
            omemoStorage->addDevice(deviceOwnerJid, deviceId, device);

            buildSessionForNewDevice(deviceOwnerJid, deviceId, device).then(q, [=, this](auto) {
                Q_EMIT q->deviceAdded(deviceOwnerJid, deviceId);
            });
        }
    }

    // Publish an own correct device list if the PEP service's one is incorrect
    // and the devices are already set up locally.
    if (isOwnDeviceListIncorrect) {
        if (!devices.isEmpty()) {
            publishDeviceListItem(true).then(q, [=, this](bool isPublished) {
                if (!isPublished) {
                    warning(u"Own device list item could not be published in order to correct the PEP service's one"_s);
                }
            });
        }
    }
}

// Corrects the own device list on the PEP service by the locally stored
// devices or sets a contact device to be removed locally in the future.
//
// \a deviceOwnerJid is bare JID of the devices' owner.
void ManagerPrivate::handleIrregularDeviceListChanges(const QString &deviceOwnerJid)
{
    const auto isOwnDeviceListNode = ownBareJid() == deviceOwnerJid;

    if (isOwnDeviceListNode) {
        // Publish a new device list for the own devices if their device list
        // item is removed, if their device list node is removed or if all
        // the node's items are removed.
        auto future = pubSubManager->deleteOwnPepNode(staticString(ns_omemo_2_devices));
        future.then(q, [=, this](QXmppPubSubManager::Result result) {
            if (const auto error = std::get_if<QXmppError>(&result)) {
                warning(u"Node '" + ns_omemo_2_devices + u"' of JID '" + deviceOwnerJid + u"' could not be deleted in order to recover from an inconsistent node: " + errorToString(*error));
            } else {
                auto future = pubSubManager->requestOwnPepFeatures();
                future.then(q, [=, this](QXmppPubSubManager::FeaturesResult result) {
                    if (const auto error = std::get_if<QXmppError>(&result)) {
                        warning(u"Features of PEP service '" + deviceOwnerJid + u"' could not be retrieved: " + errorToString(*error));
                        warning(u"Device list could not be published"_s);
                    } else {
                        const auto &pepServiceFeatures = std::get<QList<QString>>(result);
                        const auto arePublishOptionsSupported = pepServiceFeatures.contains(toString60(ns_pubsub_publish_options));
                        const auto isAutomaticCreationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_auto_create));
                        const auto isCreationAndConfigurationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_create_and_configure));
                        const auto isCreationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_create_nodes));
                        const auto isConfigurationSupported = pepServiceFeatures.contains(toString60(ns_pubsub_config_node));

                        publishDeviceElement(false,
                                             arePublishOptionsSupported,
                                             isAutomaticCreationSupported,
                                             isCreationAndConfigurationSupported,
                                             isCreationSupported,
                                             isConfigurationSupported)
                            .then(q, [=, this](bool isPublished) {
                                if (!isPublished) {
                                    warning(u"Device element could not be published"_s);
                                }
                            });
                    }
                });
            }
        });
    } else {
        auto &ownerDevices = devices[deviceOwnerJid];

        // Set a timestamp for locally stored contact devices being removed
        // later if their device list item is removed, if their device list node
        // is removed or if all the node's items are removed.
        for (auto itr = ownerDevices.begin(); itr != ownerDevices.end(); ++itr) {
            const auto &deviceId = itr.key();
            auto &device = itr.value();

            device.removalFromDeviceListDate = QDateTime::currentDateTimeUtc();

            // Store the modification.
            omemoStorage->addDevice(deviceOwnerJid, deviceId, device);
        }
    }
}

// Removes the device element for this device or deletes the whole PEP node if
// it would be empty after the retraction.
//
// \a continuation is the function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::deleteDeviceElement()
{
    if (otherOwnDevices().isEmpty()) {
        return deleteNode(staticString(ns_omemo_2_devices));
    } else {
        return publishDeviceListItem(false);
    }
}

// Creates a PEP node.
//
// \a node is node to be created. \a continuation is the function to be called with the bool value
// whether it succeeded.
QXmppTask<bool> ManagerPrivate::createNode(const QString &node)
{
    return runPubSubQueryWithContinuation(
        pubSubManager->createOwnPepNode(node),
        u"Node '" + node + u"' of JID '" + ownBareJid() + u"' could not be created");
}

// Creates a PEP node with a configuration.
//
// \a node is node to be created. \a config is configuration to be applied. \a continuation is
// function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::createNode(const QString &node, const QXmppPubSubNodeConfig &config)
{
    return runPubSubQueryWithContinuation(
        pubSubManager->createOwnPepNode(node, config),
        u"Node '" + node + u"' of JID '" + ownBareJid() + u"' could not be created");
}

// Configures an existing PEP node.
//
// \a node is node to be configured. \a config is configuration to be applied. \a continuation
// is function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::configureNode(const QString &node, const QXmppPubSubNodeConfig &config)
{
    return runPubSubQueryWithContinuation(
        pubSubManager->configureOwnPepNode(node, config),
        u"Node '" + node + u"' of JID '" + ownBareJid() + u"' could not be configured");
}

// Retracts an item from a PEP node.
//
// \a node is node containing the item. \a itemId is ID of the item. \a continuation is
// function to be called with the bool value whether it succeeded.
QXmppTask<bool> ManagerPrivate::retractItem(const QString &node, uint32_t itemId)
{
    const auto itemIdString = QString::number(itemId);
    return runPubSubQueryWithContinuation(
        pubSubManager->retractOwnPepItem(node, itemIdString),
        u"Item '" + itemIdString + u"' of node '" + node + u"' and JID '" + ownBareJid() + u"' could not be retracted");
}

// Deletes a PEP node.
//
// \a node is node to be deleted. \a continuation is the function to be called with the bool value
// whether it succeeded.
QXmppTask<bool> ManagerPrivate::deleteNode(QString node)
{
    auto result = co_await pubSubManager->deleteOwnPepNode(node).withContext(q);
    if (auto error = std::get_if<QXmppError>(&result)) {
        if (auto err = error->value<QXmppStanza::Error>()) {
            // Skip the error handling if the node is already deleted.
            if (!(err->type() == Error::Cancel && err->condition() == Error::ItemNotFound)) {
                warning(u"Node '" + node + u"' of JID '" + ownBareJid() + u"' could not be deleted: " + errorToString(*error));
                co_return false;
            } else {
                co_return true;
            }
        } else {
            co_return true;
        }
    } else {
        co_return true;
    }
}

// Publishes a PEP item.
//
// \a node is node containing the item. \a item is item to be published. \a continuation is
// function to be called with the bool value whether it succeeded.
template<typename T>
QXmppTask<bool> ManagerPrivate::publishItem(const QString &node, const T &item)
{
    return runPubSubQueryWithContinuation(
        pubSubManager->publishOwnPepItem(node, item),
        u"Item with ID '" + item.id() + u"' could not be published to node '" + node + u"' of JID '" + ownBareJid() + u"'");
}

// Publishes a PEP item with publish options.
//
// \a node is node containing the item. \a item is item to be published. \a publishOptions is
// publish options to be applied. \a continuation is the function to be called with the bool value
// whether it succeeded.
template<typename T>
QXmppTask<bool> ManagerPrivate::publishItem(const QString &node, const T &item, const QXmppPubSubPublishOptions &publishOptions)
{
    return runPubSubQueryWithContinuation(
        pubSubManager->publishOwnPepItem(node, item, publishOptions),
        u"Item with ID '" + item.id() + u"' could not be published to node '" + node + u"' of JID '" + ownBareJid() + u"'");
}

// Runs a PubSub query and processes a continuation function.
//
// \a future is PubSub query to be run. \a errorMessage is message to be logged in case of an
// error. \a continuation is the function to be called after the PubSub query.
template<typename T>
QXmppTask<bool> QXmppOmemoManagerPrivate::runPubSubQueryWithContinuation(QXmppTask<T> future, QString errorMessage)
{
    auto result = co_await future;
    if (auto error = std::get_if<QXmppError>(&result)) {
        warning(errorMessage + u": " + errorToString(*error));
        co_return false;
    } else {
        co_return true;
    }
}

// See QXmppOmemoManager for documentation
QXmppTask<bool> ManagerPrivate::changeDeviceLabel(QString deviceLabel)
{
    Q_ASSERT_X(initialized, "Changing device label", "The device label could not be changed because the OMEMO manager must be initialized");

    if (q->client()->isAuthenticated()) {
        co_await omemoStorage->setOwnDevice(ownDevice).withContext(q);
        auto published = co_await publishDeviceListItem(true).withContext(q);
        ownDevice.label = deviceLabel;
        co_return published;
    } else {
        warning(QStringLiteral("Device label could not be changed because the user is not logged in"));
        co_return false;
    }
}

// Requests the device list of a contact manually and stores it locally.
//
// This should be called for offline contacts whose servers do not distribute
// the last published PubSub item if that contact is offline (e.g., with at
// least ejabberd version <= 21.12)
//
// \a jid is JID of the contact whose device list is being requested.
//
// Returns the result of the request.
QXmppTask<QXmppPubSubManager::ItemResult<QXmppOmemoDeviceListItem>> ManagerPrivate::requestDeviceList(QString jid)
{
    // Since the usage of the item ID \c QXmppPubSubManager::Current is only RECOMMENDED by
    // \xep{0060}{Publish-Subscribe} (PubSub) but not obligatory, all items are requested even if
    // the node should contain only one item.
    auto result = co_await pubSubManager->requestItems<QXmppOmemoDeviceListItem>(jid, staticString(ns_omemo_2_devices)).withContext(q);

    if (const auto error = std::get_if<QXmppError>(&result)) {
        warning(u"Device list for JID '" + jid + u"' could not be retrieved: " + errorToString(*error));
        co_return *error;
    }

    const auto &items = std::get<QXmppPubSubManager::Items<QXmppOmemoDeviceListItem>>(result).items;
    if (items.isEmpty()) {
        QString errorMessage = u"Device list for JID '" + jid + u"' could not be retrieved because the node does not contain any item";
        warning(errorMessage);
        co_return QXmppError { errorMessage, {} };
    }

    if (const auto item = updateContactDevices(jid, items); item) {
        co_return *item;
    }

    co_return QXmppError { u"Device list for JID '" + jid + u"' could not be retrieved because the node does not contain an appropriate item", {} };
}

// Subscribes to the device list of a contact if the contact's device is not stored yet.
//
// \a jid is JID of the contact whose device list is being subscribed. \a deviceId is ID of the
// device that is checked.
void ManagerPrivate::subscribeToNewDeviceLists(const QString &jid, uint32_t deviceId)
{
    if (!devices.value(jid).contains(deviceId)) {
        subscribeToDeviceList(jid);
    }
}

// Subscribes the current user's resource to a device list manually.
//
// A server may not send the last published item automatically.
// To ensure that the subscribed device list can be stored locally in any case,
// the current PubSub item containing the device list is requested manually.
//
// \a jid is JID of the contact whose device list is being subscribed.
//
// Returns the result of the subscription and manual request.
QXmppTask<QXmppPubSubManager::Result> ManagerPrivate::subscribeToDeviceList(QString jid)
{
    auto result = co_await pubSubManager->subscribeToNode(jid, staticString(ns_omemo_2_devices), ownFullJid()).withContext(q);

    if (const auto error = std::get_if<QXmppError>(&result)) {
        warning(u"Device list for JID '" + jid + u"' could not be subscribed: " + errorToString(*error));
        co_return std::move(*error);
    }

    jidsOfManuallySubscribedDevices.append(jid);
    co_return mapToSuccess(co_await requestDeviceList(jid).withContext(q));
}

// Unsubscribes the current user's resource from device lists that were
// manually subscribed by
// \c QXmppOmemoManagerPrivate::subscribeToDeviceList().
//
// \a jids is JIDs of the contacts whose device lists are being unsubscribed.
//
// Returns the results of each unsubscribe request.
QXmppTask<QList<Manager::DevicesResult>> ManagerPrivate::unsubscribeFromDeviceLists(const QList<QString> &jids)
{
    if (jids.isEmpty()) {
        return makeReadyTask(QList<Manager::DevicesResult>());
    }

    struct State {
        int processed = 0;
        int jidsCount = 0;
        QXmppPromise<QList<Manager::DevicesResult>> interface;
        QList<Manager::DevicesResult> devicesResults;
    };

    auto state = std::make_shared<State>();
    state->jidsCount = jids.count();

    for (const auto &jid : jids) {
        unsubscribeFromDeviceList(jid).then(q, [jid, state](QXmppPubSubManager::Result result) mutable {
            state->devicesResults << Manager::DevicesResult {
                jid, result
            };

            if (++(state->processed) == state->jidsCount) {
                state->interface.finish(std::move(state->devicesResults));
            }
        });
    }

    return state->interface.task();
}

// Unsubscribes the current user's resource from a device list that were
// manually subscribed by
// \c QXmppOmemoManagerPrivate::subscribeToDeviceList().
//
// \a jid is JID of the contact whose device list is being unsubscribed.
//
// Returns the result of the unsubscription.
QXmppTask<QXmppPubSubManager::Result> ManagerPrivate::unsubscribeFromDeviceList(QString jid)
{
    auto result = co_await pubSubManager->unsubscribeFromNode(jid, staticString(ns_omemo_2_devices), ownFullJid()).withContext(q);

    if (std::get_if<QXmppError>(&result)) {
        warning(u"Device list for JID '" + jid + u"' could not be unsubscribed: " + errorToString(std::get<QXmppError>(result)));
    } else {
        jidsOfManuallySubscribedDevices.removeAll(jid);
    }

    co_return std::move(result);
}

// See QXmppOmemoManager for documentation
QXmppTask<bool> ManagerPrivate::resetOwnDevice()
{
    initialized = false;

    co_await resetOwnDeviceLocally().withContext(q);

    if (!co_await deleteDeviceElement().withContext(q)) {
        co_return false;
    }

    bool deleted = co_await deleteDeviceBundle().withContext(q);
    if (deleted) {
        resetCachedData();
    }
    co_return deleted;
}

// See QXmppOmemoManager for documentation
QXmppTask<void> QXmppOmemoManagerPrivate::resetOwnDeviceLocally()
{
    initialized = false;

    co_await trustManager->resetAll(staticString(ns_omemo_2)).withContext(q);
    co_await omemoStorage->resetAll().withContext(q);
    resetCachedData();
}

// See QXmppOmemoManager for documentation
QXmppTask<bool> ManagerPrivate::resetAll()
{
    initialized = false;

    co_await resetOwnDeviceLocally().withContext(q);

    if (!co_await deleteNode(staticString(ns_omemo_2_devices)).withContext(q)) {
        co_return false;
    }

    bool deleted = co_await deleteNode(staticString(ns_omemo_2_bundles)).withContext(q);
    if (deleted) {
        resetCachedData();
    }
    co_return deleted;
}

//
// Resets all cached OMEMO data.
//
void ManagerPrivate::resetCachedData()
{
    ownDevice = {};
    preKeyPairs.clear();
    signedPreKeyPairs.clear();
    deviceBundle = {};
    devices.clear();

    Q_EMIT q->allDevicesRemoved();
}

// Builds a new session for a new received device if that is enabled.
//
// \sa QXmppOmemoManager::setNewDeviceAutoSessionBuildingEnabled()
//
// \a jid is JID of the device's owner. \a deviceId is ID of the device. \a device is locally
// stored device which will be modified.
//
// Returns true if a session could be built or it is not enabled, otherwise false.
QXmppTask<bool> ManagerPrivate::buildSessionForNewDevice(const QString &jid, uint32_t deviceId, QXmppOmemoStorage::Device &device)
{
    if (isNewDeviceAutoSessionBuildingEnabled) {
        return buildSessionWithDeviceBundle(jid, deviceId, device);
    } else {
        return makeReadyTask(true);
    }
}

// Requests a device bundle and builds a new session with it.
//
// \a jid is JID of the device's owner. \a deviceId is ID of the device. \a device is locally
// stored device which will be modified.
//
// Returns whether a session could be built.
QXmppTask<bool> ManagerPrivate::buildSessionWithDeviceBundle(QString jid, uint32_t deviceId, QXmppOmemoStorage::Device &device)
{
    auto deviceBundle = co_await requestDeviceBundle(jid, deviceId).withContext(q);
    if (!deviceBundle) {
        warning(u"Session could not be created because no device bundle could be fetched for JID '" +
                jid + u"' and device ID '" + QString::number(deviceId) + u"'");
        co_return false;
    }

    device.keyId = deviceBundle->publicIdentityKey();

    auto trustLevel = co_await q->trustLevel(jid, device.keyId).withContext(q);
    if (trustLevel == TrustLevel::Undecided) {
        // Store the key's trust level if it is not stored yet.
        trustLevel = co_await storeKeyDependingOnSecurityPolicy(jid, device.keyId).withContext(q);
    }

    // Build a session if the device's key has a specific trust
    // level and send an empty OMEMO (key exchange) message to
    // make the receiving device build a new session too.
    if (!acceptedSessionBuildingTrustLevels.testFlag(trustLevel)) {
        warning(u"Session could not be created for JID '" + jid + u"' with device ID '" + QString::number(deviceId) + u"' because its key's trust level '" + QString::number(int(trustLevel)) + u"' is not accepted");
        co_return false;
    }

    if (const auto address = Address(jid, deviceId); !buildSession(address.data(), *deviceBundle)) {
        warning(u"Session could not be created for JID '" + jid + u"' and device ID '" + QString::number(deviceId) + u"'");
        co_return false;
    }

    auto result = co_await sendEmptyMessage(jid, deviceId).withContext(q);
    if (std::holds_alternative<QXmppError>(result)) {
        warning(u"Session could be created but empty message could not be sent to JID '" +
                jid + u"' and device ID '" + QString::number(deviceId) + u"'");
        co_return false;
    }
    co_return true;
}

// Builds an OMEMO session.
//
// A session is used for encryption and decryption.
//
// \a address is address of the device for whom the session is built. \a deviceBundle is device
// bundle containing all data to build the session.
//
// Returns whether it succeeded.
bool ManagerPrivate::buildSession(signal_protocol_address address, const QXmppOmemoDeviceBundle &deviceBundle)
{
    // Choose a pre key randomly.
    const auto publicPreKeys = deviceBundle.publicPreKeys();
    if (publicPreKeys.isEmpty()) {
        warning(u"No public pre key could be found in device bundle"_s);
        return false;
    }
    const auto publicPreKeyIds = publicPreKeys.keys();
    const auto publicPreKeyIndex = QRandomGenerator::system()->bounded(publicPreKeyIds.size());
    const auto publicPreKeyId = publicPreKeyIds.at(publicPreKeyIndex);
    const auto publicPreKey = publicPreKeys.value(publicPreKeyId);

    SessionBuilderPtr sessionBuilder;
    if (session_builder_create(sessionBuilder.ptrRef(), storeContext.get(), &address, globalContext.get()) < 0) {
        warning(u"Session builder could not be created"_s);
        return false;
    }
    session_builder_set_version(sessionBuilder.get(), CIPHERTEXT_OMEMO_VERSION);

    RefCountedPtr<session_pre_key_bundle> sessionBundle;

    if (!createSessionBundle(sessionBundle.ptrRef(),
                             deviceBundle.publicIdentityKey(),
                             deviceBundle.signedPublicPreKey(),
                             deviceBundle.signedPublicPreKeyId(),
                             deviceBundle.signedPublicPreKeySignature(),
                             publicPreKey,
                             publicPreKeyId)) {
        warning(u"Session bundle could not be created"_s);
        return false;
    }

    if (session_builder_process_pre_key_bundle(sessionBuilder.get(), sessionBundle.get()) != SG_SUCCESS) {
        warning(u"Session bundle could not be processed"_s);
        return false;
    }

    return true;
}

// Creates a session bundle.
//
// \a sessionBundle is session bundle location. \a serializedPublicIdentityKey is serialized
// public identity key. \a serializedSignedPublicPreKey is serialized signed public pre key. \a
// signedPublicPreKeyId is ID of the signed public pre key. \a
// serializedSignedPublicPreKeySignature is serialized signature of the signed public pre key.
// \a serializedPublicPreKey is serialized public pre key. \a publicPreKeyId is ID of the
// public pre key.
//
// Returns whether it succeeded.
bool ManagerPrivate::createSessionBundle(session_pre_key_bundle **sessionBundle,
                                         const QByteArray &serializedPublicIdentityKey,
                                         const QByteArray &serializedSignedPublicPreKey,
                                         uint32_t signedPublicPreKeyId,
                                         const QByteArray &serializedSignedPublicPreKeySignature,
                                         const QByteArray &serializedPublicPreKey,
                                         uint32_t publicPreKeyId)
{
    RefCountedPtr<ec_public_key> publicIdentityKey;
    RefCountedPtr<ec_public_key> signedPublicPreKey;
    RefCountedPtr<const uint8_t> signedPublicPreKeySignature;
    int signedPublicPreKeySignatureSize;
    RefCountedPtr<ec_public_key> publicPreKey;

    if (deserializePublicIdentityKey(publicIdentityKey.ptrRef(), serializedPublicIdentityKey) &&
        deserializeSignedPublicPreKey(signedPublicPreKey.ptrRef(), serializedSignedPublicPreKey) &&
        (signedPublicPreKeySignatureSize = deserializeSignedPublicPreKeySignature(signedPublicPreKeySignature.ptrRef(), serializedSignedPublicPreKeySignature)) &&
        deserializePublicPreKey(publicPreKey.ptrRef(), serializedPublicPreKey)) {

        // "0" is passed as "device_id" to the OMEMO library because it is not
        // used by OMEMO.
        // Only the device ID is of interest which is used as "registration_id"
        // within the OMEMO library.
        if (session_pre_key_bundle_create(sessionBundle,
                                          ownDevice.id,
                                          0,
                                          publicPreKeyId,
                                          publicPreKey.get(),
                                          signedPublicPreKeyId,
                                          signedPublicPreKey.get(),
                                          signedPublicPreKeySignature.get(),
                                          signedPublicPreKeySignatureSize,
                                          publicIdentityKey.get()) < 0) {
            return false;
        }

        return true;
    } else {
        warning(u"Session bundle data could not be deserialized"_s);
        return false;
    }
}

// Deserializes the locally stored identity key pair.
//
// The identity key pair is the pair of private and a public long-term keys.
//
// \a identityKeyPair is identity key pair location.
//
// Returns whether it succeeded.
bool ManagerPrivate::deserializeIdentityKeyPair(ratchet_identity_key_pair **identityKeyPair) const
{
    RefCountedPtr<ec_private_key> privateIdentityKey;
    deserializePrivateIdentityKey(privateIdentityKey.ptrRef(), ownDevice.privateIdentityKey);

    RefCountedPtr<ec_public_key> publicIdentityKey;
    deserializePublicIdentityKey(publicIdentityKey.ptrRef(), ownDevice.publicIdentityKey);

    if (ratchet_identity_key_pair_create(identityKeyPair, publicIdentityKey.get(), privateIdentityKey.get()) < 0) {
        warning(u"Identity key pair could not be deserialized"_s);
        return false;
    }

    return true;
}

// Deserializes a private identity key.
//
// \a privateIdentityKey is private identity key location. \a serializedPrivateIdentityKey is
// serialized private identity key.
//
// Returns whether it succeeded.
bool ManagerPrivate::deserializePrivateIdentityKey(ec_private_key **privateIdentityKey, const QByteArray &serializedPrivateIdentityKey) const
{
    BufferSecurePtr privateIdentityKeyBuffer = BufferSecurePtr::fromByteArray(serializedPrivateIdentityKey);

    if (!privateIdentityKeyBuffer) {
        warning(u"Buffer for serialized private identity key could not be created"_s);
        return false;
    }

    if (curve_decode_private_point(privateIdentityKey, signal_buffer_data(privateIdentityKeyBuffer.get()), signal_buffer_len(privateIdentityKeyBuffer.get()), globalContext.get()) < 0) {
        warning(u"Private identity key could not be deserialized"_s);
        return false;
    }

    return true;
}

// Deserializes a public identity key.
//
// \a publicIdentityKey is public identity key location. \a serializedPublicIdentityKey is
// serialized public identity key.
//
// Returns whether it succeeded.
bool ManagerPrivate::deserializePublicIdentityKey(ec_public_key **publicIdentityKey, const QByteArray &serializedPublicIdentityKey) const
{
    BufferPtr publicIdentityKeyBuffer = BufferPtr::fromByteArray(serializedPublicIdentityKey);

    if (!publicIdentityKeyBuffer) {
        warning(u"Buffer for serialized public identity key could not be created"_s);
        return false;
    }

    if (curve_decode_point_ed(publicIdentityKey, signal_buffer_data(publicIdentityKeyBuffer.get()), signal_buffer_len(publicIdentityKeyBuffer.get()), globalContext.get()) < 0) {
        warning(u"Public identity key could not be deserialized"_s);
        return false;
    }

    return true;
}

// Deserializes a signed public pre key.
//
// \a signedPublicPreKey is signed public pre key location. \a serializedSignedPublicPreKey is
// serialized signed public pre key.
//
// Returns whether it succeeded.
bool ManagerPrivate::deserializeSignedPublicPreKey(ec_public_key **signedPublicPreKey, const QByteArray &serializedSignedPublicPreKey) const
{
    BufferPtr signedPublicPreKeyBuffer = BufferPtr::fromByteArray(serializedSignedPublicPreKey);

    if (!signedPublicPreKeyBuffer) {
        warning(u"Buffer for serialized signed public pre key could not be created"_s);
        return false;
    }

    if (curve_decode_point_mont(signedPublicPreKey, signal_buffer_data(signedPublicPreKeyBuffer.get()), signal_buffer_len(signedPublicPreKeyBuffer.get()), globalContext.get()) < 0) {
        warning(u"Signed public pre key could not be deserialized"_s);
        return false;
    }

    return true;
}

// Deserializes a public pre key.
//
// \a publicPreKey is public pre key location. \a serializedPublicPreKey is serialized public
// pre key.
//
// Returns whether it succeeded.
bool ManagerPrivate::deserializePublicPreKey(ec_public_key **publicPreKey, const QByteArray &serializedPublicPreKey) const
{
    auto publicPreKeyBuffer = BufferPtr::fromByteArray(serializedPublicPreKey);

    if (!publicPreKeyBuffer) {
        warning(u"Buffer for serialized public pre key could not be created"_s);
        return false;
    }

    if (curve_decode_point_mont(publicPreKey, signal_buffer_data(publicPreKeyBuffer.get()), signal_buffer_len(publicPreKeyBuffer.get()), globalContext.get()) < 0) {
        warning(u"Public pre key could not be deserialized"_s);
        return false;
    }

    return true;
}

// Sends an empty OMEMO message.
//
// An empty OMEMO message is a message without an OMEMO payload.
// It is used to trigger the completion, rebuilding or refreshing of OMEMO
// sessions.
//
// \a recipientJid is JID of the message's recipient. \a recipientDeviceId is ID of the
// recipient's device.
//
// Returns the result of the sending.
QXmppTask<SendResult> ManagerPrivate::sendEmptyMessage(const QString &recipientJid, uint32_t recipientDeviceId) const
{
    const auto address = Address(recipientJid, recipientDeviceId);
    const auto decryptionData = Crypto::SecureByteArray(EMPTY_MESSAGE_DECRYPTION_DATA_SIZE);

    if (const auto envelopeData = createOmemoEnvelopeData(address.data(), decryptionData); !envelopeData) {
        warning(u"OMEMO envelope for recipient JID '" + recipientJid + u"' and device ID '" + QString::number(recipientDeviceId) + u"' could not be created because its data could not be encrypted");
        return makeReadyTask<SendResult>(QXmppError {
            u"OMEMO envelope could not be created"_s,
            SendError::EncryptionError,
        });
    } else {
        QXmppOmemoEnvelope omemoEnvelope;
        omemoEnvelope.setRecipientDeviceId(recipientDeviceId);
        omemoEnvelope.setUsedForKeyExchange(envelopeData->isKeyExchange);
        omemoEnvelope.setData(envelopeData->data);

        QXmppOmemoElement omemoElement;
        omemoElement.addEnvelope(recipientJid, omemoEnvelope);
        omemoElement.setSenderDeviceId(ownDevice.id);

        QXmppMessage message;
        message.setTo(recipientJid);
        message.addHint(QXmppMessage::Store);
        message.setOmemoElement(omemoElement);

        return q->client()->send(std::move(message));
    }
}

//
// Sets the key of this client instance's device.
//
QXmppTask<void> ManagerPrivate::storeOwnKey() const
{
    return trustManager->setOwnKey(staticString(ns_omemo_2), ownDevice.publicIdentityKey);
}

// Stores a key while its trust level is determined by the used security
// policy.
//
// \a keyOwnerJid is bare JID of the key owner. \a key is key to store.
//
// Returns the trust level of the stored key.
QXmppTask<TrustLevel> ManagerPrivate::storeKeyDependingOnSecurityPolicy(QString keyOwnerJid, QByteArray key)
{
    auto securityPolicy = co_await q->securityPolicy().withContext(q);

    switch (securityPolicy) {
    case NoSecurityPolicy:
        co_return co_await storeKey(keyOwnerJid, key);
        break;
    case Toakafa: {
        if (co_await trustManager->hasKey(staticString(ns_omemo_2), keyOwnerJid, TrustLevel::Authenticated).withContext(q)) {
            // If there is at least one authenticated key, add the
            // new key as an automatically distrusted one.
            co_return co_await storeKey(keyOwnerJid, key);
        } else {
            // If no key is authenticated yet, add the new key as an
            // automatically trusted one.
            co_return co_await storeKey(keyOwnerJid, key, TrustLevel::AutomaticallyTrusted);
        }
        break;
    }
    default:
        Q_UNREACHABLE();
    }
}

// Stores a key.
//
// \a keyOwnerJid is bare JID of the key owner. \a key is key to store. \a trustLevel is trust
// level of the key.
//
// Returns the trust level of the stored key.
QXmppTask<TrustLevel> ManagerPrivate::storeKey(QString keyOwnerJid, QByteArray key, TrustLevel trustLevel) const
{
    co_await trustManager->addKeys(staticString(ns_omemo_2), keyOwnerJid, { key }, trustLevel).withContext(q);
    Q_EMIT q->trustLevelsChanged({ { keyOwnerJid, key } });
    co_return trustLevel;
}

// Returns the own bare JID set in the client's configuration.
//
// Returns the own bare JID.
QString ManagerPrivate::ownBareJid() const
{
    return q->client()->configuration().jidBare();
}

// Returns the own full JID set in the client's configuration.
//
// Returns the own full JID.
QString ManagerPrivate::ownFullJid() const
{
    return q->client()->configuration().jid();
}

// Returns the devices with the own JID except the device of this client
// instance.
//
// Returns the other own devices.
QHash<uint32_t, QXmppOmemoStorage::Device> ManagerPrivate::otherOwnDevices()
{
    return devices.value(ownBareJid());
}

// Calls the logger warning method.
//
// \a msg is warning message.
void ManagerPrivate::warning(const QString &msg) const
{
    q->warning(msg);
}
