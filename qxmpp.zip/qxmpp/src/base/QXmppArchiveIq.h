// SPDX-FileCopyrightText: 2010 Jeremy Lainé <jeremy.laine@m4x.org>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#ifndef QXMPPARCHIVEIQ_H
#define QXMPPARCHIVEIQ_H

#include "QXmppIq.h"
#include "QXmppResultSet.h"

#include <QDateTime>

/*!
    \inmodule QXmpp

    \brief The QXmppArchiveMessage class represents an archived message
    as defined by \xep{0136}{Message Archiving}.
*/
class QXMPP_EXPORT QXmppArchiveMessage
{
public:
    QXmppArchiveMessage();

    QString body() const;
    void setBody(const QString &body);

    QDateTime date() const;
    void setDate(const QDateTime &date);

    bool isReceived() const;
    void setReceived(bool isReceived);

private:
    QString m_body;
    QDateTime m_date;
    bool m_received;
};

/*!
    \inmodule QXmpp

    \brief The QXmppArchiveChat class represents an archived conversation
    as defined by \xep{0136}{Message Archiving}.
*/
class QXMPP_EXPORT QXmppArchiveChat
{
public:
    QXmppArchiveChat();

    QList<QXmppArchiveMessage> messages() const;
    void setMessages(const QList<QXmppArchiveMessage> &messages);

    QDateTime start() const;
    void setStart(const QDateTime &start);

    QString subject() const;
    void setSubject(const QString &subject);

    QString thread() const;
    void setThread(const QString &thread);

    int version() const;
    void setVersion(int version);

    QString with() const;
    void setWith(const QString &with);

    static constexpr std::tuple XmlTag = { u"chat", QXmpp::Private::ns_archive };
    void parse(const QDomElement &element);
    void toXml(QXmlStreamWriter *writer) const { toXml(writer, {}); }
    void toXml(QXmlStreamWriter *writer, const QXmppResultSetReply &rsm) const;

private:
    QList<QXmppArchiveMessage> m_messages;
    QDateTime m_start;
    QString m_subject;
    QString m_thread;
    int m_version;
    QString m_with;
};

/*!
    \inmodule QXmpp

    \brief Represents an archive chat as defined by \xep{0136}{Message Archiving}.

    It is used to get chat as a QXmppArchiveChat.

    \ingroup Stanzas
*/
class QXMPP_EXPORT QXmppArchiveChatIq : public QXmppIq
{
public:
    QXmppArchiveChat chat() const;
    void setChat(const QXmppArchiveChat &chat);

    QXmppResultSetReply resultSetReply() const;
    void setResultSetReply(const QXmppResultSetReply &rsm);

    static constexpr std::tuple PayloadXmlTag = { u"chat", QXmpp::Private::ns_archive };
    [[deprecated("Use QXmpp::isIqElement()")]]
    static bool isArchiveChatIq(const QDomElement &element);

protected:
    void parseElementFromChild(const QDomElement &element) override;
    void toXmlElementFromChild(QXmlStreamWriter *writer) const override;

private:
    QXmppArchiveChat m_chat;
    QXmppResultSetReply m_rsmReply;
};

/*!
    \inmodule QXmpp

    \brief Represents an archive list as defined by \xep{0136}{Message Archiving}.

    \ingroup Stanzas
*/
class QXMPP_EXPORT QXmppArchiveListIq : public QXmppIq
{
public:
    QXmppArchiveListIq();

    QList<QXmppArchiveChat> chats() const;
    void setChats(const QList<QXmppArchiveChat> &chats);

    QString with() const;
    void setWith(const QString &with);

    QDateTime start() const;
    void setStart(const QDateTime &start);

    QDateTime end() const;
    void setEnd(const QDateTime &end);

    QXmppResultSetQuery resultSetQuery() const;
    void setResultSetQuery(const QXmppResultSetQuery &rsm);

    QXmppResultSetReply resultSetReply() const;
    void setResultSetReply(const QXmppResultSetReply &rsm);

    static constexpr std::tuple PayloadXmlTag = { u"list", QXmpp::Private::ns_archive };
    [[deprecated("Use QXmpp::isIqElement()")]]
    static bool isArchiveListIq(const QDomElement &element);

protected:
    void parseElementFromChild(const QDomElement &element) override;
    void toXmlElementFromChild(QXmlStreamWriter *writer) const override;

private:
    QString m_with;
    QDateTime m_start;
    QDateTime m_end;
    QList<QXmppArchiveChat> m_chats;
    QXmppResultSetQuery m_rsmQuery;
    QXmppResultSetReply m_rsmReply;
};

/*!
    \inmodule QXmpp

    \brief Represents an archive remove IQ as defined by \xep{0136}{Message Archiving}.

    \ingroup Stanzas
*/
class QXMPP_EXPORT QXmppArchiveRemoveIq : public QXmppIq
{
public:
    QString with() const;
    void setWith(const QString &with);

    QDateTime start() const;
    void setStart(const QDateTime &start);

    QDateTime end() const;
    void setEnd(const QDateTime &end);

    static constexpr std::tuple PayloadXmlTag = { u"remove", QXmpp::Private::ns_archive };
    [[deprecated("Use QXmpp::isIqElement()")]]
    static bool isArchiveRemoveIq(const QDomElement &element);

protected:
    void parseElementFromChild(const QDomElement &element) override;
    void toXmlElementFromChild(QXmlStreamWriter *writer) const override;

private:
    QString m_with;
    QDateTime m_start;
    QDateTime m_end;
};

/*!
    \inmodule QXmpp

    \brief Represents an archive retrieve IQ as defined by \xep{0136}{Message Archiving}.

    \ingroup Stanzas
*/
class QXMPP_EXPORT QXmppArchiveRetrieveIq : public QXmppIq
{
public:
    QXmppArchiveRetrieveIq();

    QDateTime start() const;
    void setStart(const QDateTime &start);

    QString with() const;
    void setWith(const QString &with);

    QXmppResultSetQuery resultSetQuery() const;
    void setResultSetQuery(const QXmppResultSetQuery &rsm);

    static constexpr std::tuple PayloadXmlTag = { u"retrieve", QXmpp::Private::ns_archive };
    [[deprecated("Use QXmpp::isIqElement()")]]
    static bool isArchiveRetrieveIq(const QDomElement &element);

protected:
    void parseElementFromChild(const QDomElement &element) override;
    void toXmlElementFromChild(QXmlStreamWriter *writer) const override;

private:
    QString m_with;
    QDateTime m_start;
    QXmppResultSetQuery m_rsmQuery;
};

/*!
    \inmodule QXmpp

    \brief Represents an archive preference IQ as defined by \xep{0136}{Message Archiving}.

    \ingroup Stanzas
*/
class QXMPP_EXPORT QXmppArchivePrefIq : public QXmppIq
{
public:
    static constexpr std::tuple PayloadXmlTag = { u"pref", QXmpp::Private::ns_archive };
    [[deprecated("Use QXmpp::isIqElement()")]]
    static bool isArchivePrefIq(const QDomElement &element);

protected:
    void parseElementFromChild(const QDomElement &element) override;
    void toXmlElementFromChild(QXmlStreamWriter *writer) const override;
};

#endif  // QXMPPARCHIVEIQ_H
