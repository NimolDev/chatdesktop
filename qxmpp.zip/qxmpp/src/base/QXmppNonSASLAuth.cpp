// SPDX-FileCopyrightText: 2009 Manjeet Dahiya <manjeetdahiya@gmail.com>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#include "QXmppNonSASLAuth.h"

#include "QXmppConstants_p.h"
#include "QXmppUtils.h"
#include "QXmppUtils_p.h"

#include "StringLiterals.h"
#include "XmlWriter.h"

#include <QCryptographicHash>
#include <QDomElement>
#include <QXmlStreamWriter>

using namespace QXmpp::Private;

/*!
    \class QXmppNonSASLAuthIq
    \inmodule QXmpp

    QXmppNonSASLAuthIq represents a Non-SASL authentication IQ as defined by
    \xep{0078}{Non-SASL Authentication}.

    \ingroup Stanzas
*/

QXmppNonSASLAuthIq::QXmppNonSASLAuthIq()
    : QXmppIq(QXmppIq::Set)
{
}

/*! Returns the username of the account */
QString QXmppNonSASLAuthIq::username() const
{
    return m_username;
}

/*! Sets the \a username of the account */
void QXmppNonSASLAuthIq::setUsername(const QString &username)
{
    m_username = username;
}

/*! Returns the SHA1 hash of the concatenated string */
QByteArray QXmppNonSASLAuthIq::digest() const
{
    return m_digest;
}

/*!
    Sets the digest by creating a hash of the concatenation of streamId and
    password.

    \a password and \a streamId.
*/
void QXmppNonSASLAuthIq::setDigest(const QString &streamId, const QString &password)
{
    m_digest = QCryptographicHash::hash(QByteArray(streamId.toUtf8() + password.toUtf8()), QCryptographicHash::Sha1);
}

/*! Returns the username of the account in plaintext */
QString QXmppNonSASLAuthIq::password() const
{
    return m_password;
}

/*!
    Sets the username of the account in plaintext

    \a password.
*/
void QXmppNonSASLAuthIq::setPassword(const QString &password)
{
    m_password = password;
}

/*! Returns the resource to bind to */
QString QXmppNonSASLAuthIq::resource() const
{
    return m_resource;
}

/*! Sets the \a resource to bind to */
void QXmppNonSASLAuthIq::setResource(const QString &resource)
{
    m_resource = resource;
}

void QXmppNonSASLAuthIq::parseElementFromChild(const QDomElement &element)
{
    QDomElement queryElement = element.firstChildElement(u"query"_s);
    m_username = queryElement.firstChildElement(u"username"_s).text();
    m_password = queryElement.firstChildElement(u"password"_s).text();
    m_digest = QByteArray::fromHex(queryElement.firstChildElement(u"digest"_s).text().toLatin1());
    m_resource = queryElement.firstChildElement(u"resource"_s).text();
}

void QXmppNonSASLAuthIq::toXmlElementFromChild(QXmlStreamWriter *writer) const
{
    XmlWriter(writer).write(Element {
        PayloadXmlTag,
        OptionalTextElement { u"username", m_username },
        OptionalTextElement { u"digest", m_digest.toHex() },
        OptionalTextElement { u"password", m_password },
        OptionalTextElement { u"resource", m_resource },
    });
}
