// SPDX-FileCopyrightText: 2010 Manjeet Dahiya <manjeetdahiya@gmail.com>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#include "QXmppEntityTimeManager.h"

#include "QXmppClient.h"
#include "QXmppConstants_p.h"
#include "QXmppEntityTimeIq.h"
#include "QXmppIqHandling.h"
#include "QXmppUtils.h"

#include "StringLiterals.h"

#include <QDateTime>
#include <QDomElement>
#include <QTimeZone>

using namespace QXmpp;
using namespace QXmpp::Private;

/*!
    \typedef QXmppEntityTimeManager::EntityTimeResult

    Contains the requested entity time or the returned error in case of a
    failure.

    \since QXmpp 1.5
*/

/*!
    Request the time from the XMPP entity with JID \a jid.

    The result is emitted on the timeReceived() signal.
*/
QString QXmppEntityTimeManager::requestTime(const QString &jid)
{
    QXmppEntityTimeIq request;
    request.setType(QXmppIq::Get);
    request.setTo(jid);
    return client()->sendLegacyId(request);
}

/*!
    Requests the time from an XMPP entity and reports it via a QFuture.

    The timeReceived() signal is not emitted.

    \since QXmpp 1.5

    \a jid.
*/
auto QXmppEntityTimeManager::requestEntityTime(const QString &jid) -> QXmppTask<EntityTimeResult>
{
    QXmppEntityTimeIq iq;
    iq.setType(QXmppIq::Get);
    iq.setTo(jid);

    co_return parseIq<QXmppEntityTimeIq>(co_await client()->sendIq(std::move(iq)));
}

QStringList QXmppEntityTimeManager::discoveryFeatures() const
{
    return { staticString(ns_entity_time) };
}

bool QXmppEntityTimeManager::handleStanza(const QDomElement &element)
{
    if (handleIqRequests<QXmppEntityTimeIq>(element, client(), this)) {
        return true;
    }

    if (isIqElement<QXmppEntityTimeIq>(element)) {
        QXmppEntityTimeIq entityTime;
        entityTime.parse(element);
        Q_EMIT timeReceived(entityTime);
        return true;
    }

    return false;
}

std::variant<QXmppEntityTimeIq, QXmppStanza::Error> QXmppEntityTimeManager::handleIq(QXmppEntityTimeIq iq)
{
    using Err = QXmppStanza::Error;
    if (iq.type() != QXmppIq::Get) {
        return Err(Err::Cancel, Err::BadRequest, u"Only IQ requests of type 'get' allowed."_s);
    }

    QXmppEntityTimeIq responseIq;
    QDateTime currentTime = QDateTime::currentDateTime();
    QDateTime utc = currentTime.toUTC();
    responseIq.setUtc(utc);

#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    currentTime.setTimeZone(QTimeZone::Initialization::UTC);
#else
    currentTime.setTimeZone(QTimeZone(0));
#endif
    responseIq.setTzo(utc.secsTo(currentTime));
    return responseIq;
}
