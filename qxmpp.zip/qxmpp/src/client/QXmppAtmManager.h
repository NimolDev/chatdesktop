// SPDX-FileCopyrightText: 2021 Melvin Keskin <melvo@olomono.de>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#ifndef QXMPPATMMANAGER_H
#define QXMPPATMMANAGER_H

#include "QXmppAtmTrustStorage.h"
#include "QXmppSendResult.h"
#include "QXmppTrustManager.h"

class QXmppMessage;
class QXmppTrustMessageKeyOwner;
template<typename T>
class QXmppTask;

class QXMPP_EXPORT QXmppAtmManager : public QXmppTrustManager
{
    Q_OBJECT

public:
    QXmppAtmManager(QXmppAtmTrustStorage *trustStorage);
    QXmppTask<void> makeTrustDecisions(QString encryption, QString keyOwnerJid, QList<QByteArray> keyIdsForAuthentication, QList<QByteArray> keyIdsForDistrusting = {});

protected:
    void onRegistered(QXmppClient *client) override;
    void onUnregistered(QXmppClient *client) override;

private:
    QXmppTask<void> makeTrustDecisions(QString encryption, QMultiHash<QString, QByteArray> keyIdsForAuthentication, QMultiHash<QString, QByteArray> keyIdsForDistrusting);
    QXmppTask<void> handleMessage(const QXmppMessage &message);

    QXmppTask<void> distrustAutomaticallyTrustedKeys(const QString &encryption, const QList<QString> &keyOwnerJids);
    QXmppTask<void> makePostponedTrustDecisions(QString encryption, const QList<QByteArray> &senderKeyIds);

    QXmppTask<QXmpp::SendResult> sendTrustMessage(const QString &encryption, const QList<QXmppTrustMessageKeyOwner> &keyOwners, const QString &recipientJid);

    inline QXmppAtmTrustStorage *trustStorage() const
    {
        return dynamic_cast<QXmppAtmTrustStorage *>(QXmppTrustManager::trustStorage());
    }

    friend class tst_QXmppTrustManager;
};

#endif  // QXMPPATMMANAGER_H
