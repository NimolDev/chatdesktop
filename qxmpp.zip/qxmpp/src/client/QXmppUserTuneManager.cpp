// SPDX-FileCopyrightText: 2021 Linus Jahn <lnj@kaidan.im>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#include "QXmppUserTuneManager.h"

#include "QXmppConstants_p.h"
#include "QXmppPep_p.h"
#include "QXmppUserTuneItem.h"

using namespace QXmpp::Private;

static QXmppPubSubManager *pubSub(QXmppClient *client)
{
    return client->findExtension<QXmppPubSubManager>();
}

/*!
    \class QXmppUserTuneManager
    \inmodule QXmpp

    The QXmppUserTuneManager implements \xep{0118}{User Tune}. You'll receive
    tune updates from all presence subscriptions. You can publish tune
    information on the user's account (publish()) and request tune information
    from specific accounts (request()).

    The manager needs to be added to the client first and also requires the
    QXmppPubSubManager.
    \code
    QXmppClient client;
    auto *pubSubManager = client.addNewExtension<QXmppPubSubManager>();
    auto *tuneManager = client.addNewExtension<QXmppUserTuneManager>();
    \endcode

    \since QXmpp 1.5

    \ingroup Managers
*/

/*!
    \typedef QXmppUserTuneManager::Item

    Used pubsub item type.
*/

/*!
    \typedef QXmppUserTuneManager::GetResult

    Contains the User Tune information or an error.
*/

/*!
    \typedef QXmppUserTuneManager::PublishResult

    Contains the ID of the published item on success or a stanza error.
*/

/*!
    \fn void QXmppUserTuneManager::itemReceived(const QString &jid, const QXmppTuneItem &item)

    Emitted whenever a \xep{0118}{User Tune} items event arrives.

    \a jid is the JID of the contact. \a item contains the received tune data.
*/

QXmppUserTuneManager::QXmppUserTuneManager()
{
}

QStringList QXmppUserTuneManager::discoveryFeatures() const
{
    return {
        staticString(ns_tune),
        staticString(ns_tune_notify),
    };
}

/*!
    Request User Tune information from the account with JID \a jid.
*/
auto QXmppUserTuneManager::request(const QString &jid)
    -> QXmppTask<GetResult>
{
    return Pep::request<Item>(pubSub(client()), jid, staticString(ns_tune), this);
}

/*!
    Publishes the User Tune \a item on the user's account.
*/
auto QXmppUserTuneManager::publish(const QXmppTuneItem &item)
    -> QXmppTask<PublishResult>
{
    return pubSub(client())->publishOwnPepItem(staticString(ns_tune), item);
}

bool QXmppUserTuneManager::handlePubSubEvent(const QDomElement &element, const QString &pubSubService, const QString &nodeName)
{
    return Pep::handlePubSubEvent<Item>(element, pubSubService, nodeName, staticString(ns_tune), this, &QXmppUserTuneManager::itemReceived);
}
