// SPDX-FileCopyrightText: 2016 Niels Ole Salscheider <niels_ole@salscheider-online.de>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#ifndef QXMPPMAMMANAGER_H
#define QXMPPMAMMANAGER_H

#include "QXmppClientExtension.h"
#include "QXmppError.h"
#include "QXmppMamIq.h"
#include "QXmppResultSet.h"

#include <variant>

#include <QDateTime>

template<typename T>
class QXmppTask;
class QXmppMessage;
class QXmppMamManagerPrivate;

/*!
    \inmodule QXmpp

    \brief The QXmppMamManager class makes it possible to access message
    archives as defined by \xep{0313}{Message Archive Management}.

    To make use of this manager, you need to instantiate it and load it into
    the QXmppClient instance as follows:

    \code
    QXmppMamManager *manager = new QXmppMamManager;
    client->addExtension(manager);
    \endcode

    \ingroup Managers

    \since QXmpp 1.0
*/
class QXMPP_EXPORT QXmppMamManager : public QXmppClientExtension
{
    Q_OBJECT

public:
    struct QXMPP_EXPORT RetrievedMessages {
        QXmppMamResultIq result;
        QList<QXmppMessage> messages;
    };

    using RetrieveResult = std::variant<RetrievedMessages, QXmppError>;

    QXmppMamManager();
    ~QXmppMamManager();

    QString retrieveArchivedMessages(const QString &to = QString(),
                                     const QString &node = QString(),
                                     const QString &jid = QString(),
                                     const QDateTime &start = QDateTime(),
                                     const QDateTime &end = QDateTime(),
                                     const QXmppResultSetQuery &resultSetQuery = QXmppResultSetQuery());
    QXmppTask<RetrieveResult> retrieveMessages(const QString &to = QString(),
                                               const QString &node = QString(),
                                               const QString &jid = QString(),
                                               const QDateTime &start = QDateTime(),
                                               const QDateTime &end = QDateTime(),
                                               const QXmppResultSetQuery &resultSetQuery = QXmppResultSetQuery());

    QStringList discoveryFeatures() const override;
    bool handleStanza(const QDomElement &element) override;

    /*!
        This signal is emitted when an archived \a message is received

        \a queryId.
    */
    Q_SIGNAL void archivedMessageReceived(const QString &queryId, const QXmppMessage &message);

    /*!
        This signal is emitted when all results for a request have been received

        \a complete, \a queryId, and \a resultSetReply.
    */
    Q_SIGNAL void resultsRecieved(const QString &queryId, const QXmppResultSetReply &resultSetReply, bool complete);

private:
    std::unique_ptr<QXmppMamManagerPrivate> d;
};

#endif
