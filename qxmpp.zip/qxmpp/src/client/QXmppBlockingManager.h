// SPDX-FileCopyrightText: 2023 Linus Jahn <lnj@kaidan.im>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#ifndef QXMPPBLOCKINGMANAGER_H
#define QXMPPBLOCKINGMANAGER_H

#include "QXmppClientExtension.h"
#include "QXmppError.h"
#include "QXmppTask.h"

#include <variant>

#include <QList>

class QXmppSpamReport;
struct QXmppBlockingManagerPrivate;

class QXMPP_EXPORT QXmppBlocklist
{
public:
    /*!
        \inmodule QXmpp
        \brief Indicates that the queried JID is not blocked.
    */
    struct NotBlocked { };
    /*!
        \inmodule QXmpp
        \brief Indicates that the queried JID is fully blocked.
    */
    struct Blocked {
        QList<QString> blockingEntries;
        QList<QString> partiallyBlockingEntries;
    };
    /*!
        \inmodule QXmpp
        \brief Indicates that only some resources or nodes of the queried JID are blocked.
    */
    struct PartiallyBlocked {
        QList<QString> partiallyBlockingEntries;
    };

    using BlockingState = std::variant<NotBlocked, PartiallyBlocked, Blocked>;

    QXmppBlocklist();
    QXmppBlocklist(QList<QString> entries);
    QXMPP_PRIVATE_DECLARE_RULE_OF_SIX(QXmppBlocklist)

    QList<QString> entries() const;
    bool containsEntry(QStringView) const;
    BlockingState blockingState(const QString &jid) const;

private:
    QList<QString> m_blocklist;
};

class QXMPP_EXPORT QXmppBlockingManager : public QXmppClientExtension
{
    Q_OBJECT

    /*!
        \property QXmppBlockingManager::subscribed

        Whether the blocking manager is currently receiving updates of the blocklist.
    */
    Q_PROPERTY(bool subscribed READ isSubscribed NOTIFY subscribedChanged)

public:
    using BlocklistResult = std::variant<QXmppBlocklist, QXmppError>;
    using Result = std::variant<QXmpp::Success, QXmppError>;

    QXmppBlockingManager();
    ~QXmppBlockingManager() override;

    bool isSubscribed() const;
    Q_SIGNAL void subscribedChanged();

    QXmppTask<BlocklistResult> fetchBlocklist();
    QXmppTask<Result> block(QString jid) { return block(QList<QString> { std::move(jid) }); }
    QXmppTask<Result> block(QList<QString> jids);
    QXmppTask<Result> unblock(QString jid) { return unblock(QList<QString> { std::move(jid) }); }
    QXmppTask<Result> unblock(QList<QString> jids);

    QXmppTask<Result> reportAndBlock(QString jid, QXmppSpamReport report);

    Q_SIGNAL void blocked(const QList<QString> &jids);
    Q_SIGNAL void unblocked(const QList<QString> &jids);

    QStringList discoveryFeatures() const override;
    void onRegistered(QXmppClient *) override;
    void onUnregistered(QXmppClient *) override;
    bool handleStanza(const QDomElement &, const std::optional<QXmppE2eeMetadata> &) override;

private:
    void onConnected();

    std::unique_ptr<QXmppBlockingManagerPrivate> d;
};

#endif  // QXMPPBLOCKINGMANAGER_H
