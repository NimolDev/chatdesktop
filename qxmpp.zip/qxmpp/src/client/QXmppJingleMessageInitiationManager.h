// SPDX-FileCopyrightText: 2023 Tibor Csötönyi <work@taibsu.de>
// SPDX-FileCopyrightText: 2023 Melvin Keskin <melvo@olomono.de>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#ifndef QXMPPJINGLEMESSAGEINITIATIONMANAGER_H
#define QXMPPJINGLEMESSAGEINITIATIONMANAGER_H

#include "QXmppClientExtension.h"
#include "QXmppError.h"
#include "QXmppJingleIq.h"
#include "QXmppMessageHandler.h"
#include "QXmppSendResult.h"
#include "QXmppTask.h"

class QXmppJingleMessageInitiationManager;
class QXmppJingleMessageInitiationPrivate;
class QXmppJingleMessageInitiationManagerPrivate;

class QXMPP_EXPORT QXmppJingleMessageInitiation : public QObject
{
    Q_OBJECT
public:
    /*!
        \inmodule QXmpp
        \brief Indicates that the session was rejected by the remote party.
    */
    struct Rejected {
        std::optional<QXmppJingleReason> reason;
        bool containsTieBreak;
    };

    /*!
        \inmodule QXmpp
        \brief Indicates that the session proposal was retracted by the initiator.
    */
    struct Retracted {
        std::optional<QXmppJingleReason> reason;
        bool containsTieBreak;
    };

    /*!
        \inmodule QXmpp
        \brief Indicates that the session has finished.
    */
    struct Finished {
        std::optional<QXmppJingleReason> reason;
        QString migratedTo;
    };

    /*!
        \typealias QXmppJingleMessageInitiation::Result

        Variant of Rejected, Retracted, Finished or Error result types.
    */
    using Result = std::variant<Rejected, Retracted, Finished, QXmppError>;

    ~QXmppJingleMessageInitiation();

    const QString &remoteJid() const;

    QXmppTask<QXmpp::SendResult> ring();
    QXmppTask<QXmpp::SendResult> proceed();
    QXmppTask<QXmpp::SendResult> reject(std::optional<QXmppJingleReason> reason, bool containsTieBreak = false);
    QXmppTask<QXmpp::SendResult> retract(std::optional<QXmppJingleReason> reason, bool containsTieBreak = false);
    QXmppTask<QXmpp::SendResult> finish(std::optional<QXmppJingleReason> reason, const QString &migratedTo = {});

    Q_SIGNAL void ringing();
    Q_SIGNAL void proceeded(const QString &id, const QString &remoteResource);
    Q_SIGNAL void closed(const Result &result);

private:
    QXmppJingleMessageInitiation(QXmppJingleMessageInitiationManager *manager, const QString &id, const QString &remoteJid);

    QString id() const;
    void setId(const QString &id);
    void setRemoteJid(const QString &remoteJid);
    bool isProceeded() const;
    void setIsProceeded(bool isProceeded);
    bool isFinished() const;

    std::unique_ptr<QXmppJingleMessageInitiationPrivate> d;

    friend class QXmppJingleMessageInitiationManager;
    friend class tst_QXmppJingleMessageInitiationManager;
};

class QXMPP_EXPORT QXmppJingleMessageInitiationManager : public QXmppClientExtension, public QXmppMessageHandler
{
    Q_OBJECT
public:
    using ProposeResult = std::variant<std::shared_ptr<QXmppJingleMessageInitiation>, QXmppError>;

    QXmppJingleMessageInitiationManager();
    ~QXmppJingleMessageInitiationManager();

    QStringList discoveryFeatures() const override;

    QXmppTask<ProposeResult> propose(
        const QString &remoteJid,
        const QXmppJingleRtpDescription &description);
    QXmppTask<ProposeResult> propose(
        const QString &remoteJid,
        const QList<QXmppJingleRtpDescription> &descriptions);

    Q_SIGNAL void proposed(
        const std::shared_ptr<QXmppJingleMessageInitiation> &jmi,
        const QString &id,
        const std::optional<QXmppJingleRtpDescription> &description);
    Q_SIGNAL void proposeReceived(
        const std::shared_ptr<QXmppJingleMessageInitiation> &jmi,
        const QString &id,
        const QList<QXmppJingleRtpDescription> &descriptions);

protected:
    bool handleMessage(const QXmppMessage &) override;

private:
    QXmppTask<ProposeResult> propose(
        QString id,
        QString remoteJid,
        const QList<QXmppJingleRtpDescription> &descriptions);
    QXmppTask<QXmpp::SendResult> sendMessage(
        const QXmppJingleMessageInitiationElement &jmiElement,
        const QString &remoteJid);

    void clear(const std::shared_ptr<QXmppJingleMessageInitiation> &jmi);
    void clearAll();

    bool handleJmiElement(QXmppJingleMessageInitiationElement &&jmiElement, const QString &remoteJid);
    bool handleExistingJmi(const std::shared_ptr<QXmppJingleMessageInitiation> &existingJmi, const QXmppJingleMessageInitiationElement &jmiElement, const QString &remoteResource);
    bool handleProposeJmiElement(const QXmppJingleMessageInitiationElement &jmiElement, const QString &remoteJid);
    bool handleTieBreak(const std::shared_ptr<QXmppJingleMessageInitiation> &existingJmi, const QXmppJingleMessageInitiationElement &jmiElement, const QString &remoteResource);
    bool handleExistingSession(const std::shared_ptr<QXmppJingleMessageInitiation> &existingJmi, const QString &jmiElementId);
    bool handleNonExistingSession(const std::shared_ptr<QXmppJingleMessageInitiation> &existingJmi, const QString &jmiElementId, const QString &remoteResource);
    std::shared_ptr<QXmppJingleMessageInitiation> addJmi(const QString &id, const QString &remoteJid);
    const QList<std::shared_ptr<QXmppJingleMessageInitiation>> &jmis() const;

private:
    std::unique_ptr<QXmppJingleMessageInitiationManagerPrivate> d;

    friend class QXmppJingleMessageInitiationPrivate;
    friend class tst_QXmppJingleMessageInitiationManager;
};

Q_DECLARE_METATYPE(QXmppJingleMessageInitiation::Result)

#endif  // QXMPPJINGLEMESSAGEINITIATIONMANAGER_H
